package com.zng.mrdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MrdemoApplicationTests {

    @Test
    void contextLoads() {
    }

}

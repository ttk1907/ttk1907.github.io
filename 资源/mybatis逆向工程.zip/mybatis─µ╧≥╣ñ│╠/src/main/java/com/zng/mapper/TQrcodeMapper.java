package com.zng.mapper;

import com.zng.model.TQrcode;

public interface TQrcodeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TQrcode record);

    int insertSelective(TQrcode record);

    TQrcode selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TQrcode record);

    int updateByPrimaryKey(TQrcode record);
}
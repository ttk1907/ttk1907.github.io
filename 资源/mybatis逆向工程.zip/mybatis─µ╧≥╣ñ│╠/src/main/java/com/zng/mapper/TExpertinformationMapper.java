package com.zng.mapper;

import com.zng.model.TExpertinformation;

public interface TExpertinformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TExpertinformation record);

    int insertSelective(TExpertinformation record);

    TExpertinformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TExpertinformation record);

    int updateByPrimaryKey(TExpertinformation record);
}
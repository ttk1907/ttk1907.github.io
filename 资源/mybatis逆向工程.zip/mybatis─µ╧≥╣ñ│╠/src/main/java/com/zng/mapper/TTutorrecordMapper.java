package com.zng.mapper;

import com.zng.model.TTutorrecord;

public interface TTutorrecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTutorrecord record);

    int insertSelective(TTutorrecord record);

    TTutorrecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTutorrecord record);

    int updateByPrimaryKey(TTutorrecord record);
}
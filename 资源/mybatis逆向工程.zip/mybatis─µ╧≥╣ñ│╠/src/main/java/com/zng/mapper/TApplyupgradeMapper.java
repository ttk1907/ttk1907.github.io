package com.zng.mapper;

import com.zng.model.TApplyupgrade;

public interface TApplyupgradeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TApplyupgrade record);

    int insertSelective(TApplyupgrade record);

    TApplyupgrade selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TApplyupgrade record);

    int updateByPrimaryKey(TApplyupgrade record);
}
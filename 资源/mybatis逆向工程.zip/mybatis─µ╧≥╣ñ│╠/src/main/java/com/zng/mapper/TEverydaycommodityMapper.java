package com.zng.mapper;

import com.zng.model.TEverydaycommodity;

public interface TEverydaycommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TEverydaycommodity record);

    int insertSelective(TEverydaycommodity record);

    TEverydaycommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TEverydaycommodity record);

    int updateByPrimaryKey(TEverydaycommodity record);
}
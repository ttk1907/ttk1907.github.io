package com.zng.mapper;

import com.zng.model.TActivitylucky;

public interface TActivityluckyMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivitylucky record);

    int insertSelective(TActivitylucky record);

    TActivitylucky selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivitylucky record);

    int updateByPrimaryKey(TActivitylucky record);
}
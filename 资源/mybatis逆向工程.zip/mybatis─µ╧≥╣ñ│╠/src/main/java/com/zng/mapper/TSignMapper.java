package com.zng.mapper;

import com.zng.model.TSign;

public interface TSignMapper {
    int deleteByPrimaryKey(String id);

    int insert(TSign record);

    int insertSelective(TSign record);

    TSign selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TSign record);

    int updateByPrimaryKey(TSign record);
}
package com.zng.mapper;

import com.zng.model.TWelfarericecard;

public interface TWelfarericecardMapper {
    int deleteByPrimaryKey(String id);

    int insert(TWelfarericecard record);

    int insertSelective(TWelfarericecard record);

    TWelfarericecard selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TWelfarericecard record);

    int updateByPrimaryKey(TWelfarericecard record);
}
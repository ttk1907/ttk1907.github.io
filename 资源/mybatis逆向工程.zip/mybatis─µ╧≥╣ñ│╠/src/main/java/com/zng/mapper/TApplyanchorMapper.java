package com.zng.mapper;

import com.zng.model.TApplyanchor;

public interface TApplyanchorMapper {
    int deleteByPrimaryKey(String id);

    int insert(TApplyanchor record);

    int insertSelective(TApplyanchor record);

    TApplyanchor selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TApplyanchor record);

    int updateByPrimaryKey(TApplyanchor record);
}
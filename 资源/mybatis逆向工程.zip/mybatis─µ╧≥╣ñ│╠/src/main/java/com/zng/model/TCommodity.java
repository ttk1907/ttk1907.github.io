package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TCommodity implements Serializable {
    private String id;

    private String rateTemplateId;

    private String name;

    private String details;

    private String imgUrl;

    private String state;

    private String createTime;

    private String updateTime;

    private String detailsUrl;

    private String diagram;

    private String weight;

    private String mainState;

    private String originPlace;

    private String qualityLevel;

    private String guaranteePeriod;

    private String saveMethod;

    private String variety;

    private String salesType;

    private BigDecimal token;

    private String packing;

    private String groupUrl;

    private Integer sort;

    private String isGiftsbuy;

    private String businessId;

    private String categoryId;

    private String minBuyNum;

    private String isMonthCommodity;

    private String isMonthRandom;

    private Integer monthCommodityNum;

    private String isCustomizationCommodity;

    private String iconType;

    private Integer customizationNum;

    private String detailState;

    private String detailType;

    private String isCooperation;

    private String platformType;

    private String uprightUrl;

    private Integer limitNum;

    private String shareUrl;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getRateTemplateId() {
        return rateTemplateId;
    }

    public void setRateTemplateId(String rateTemplateId) {
        this.rateTemplateId = rateTemplateId == null ? null : rateTemplateId.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details == null ? null : details.trim();
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getDetailsUrl() {
        return detailsUrl;
    }

    public void setDetailsUrl(String detailsUrl) {
        this.detailsUrl = detailsUrl == null ? null : detailsUrl.trim();
    }

    public String getDiagram() {
        return diagram;
    }

    public void setDiagram(String diagram) {
        this.diagram = diagram == null ? null : diagram.trim();
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight == null ? null : weight.trim();
    }

    public String getMainState() {
        return mainState;
    }

    public void setMainState(String mainState) {
        this.mainState = mainState == null ? null : mainState.trim();
    }

    public String getOriginPlace() {
        return originPlace;
    }

    public void setOriginPlace(String originPlace) {
        this.originPlace = originPlace == null ? null : originPlace.trim();
    }

    public String getQualityLevel() {
        return qualityLevel;
    }

    public void setQualityLevel(String qualityLevel) {
        this.qualityLevel = qualityLevel == null ? null : qualityLevel.trim();
    }

    public String getGuaranteePeriod() {
        return guaranteePeriod;
    }

    public void setGuaranteePeriod(String guaranteePeriod) {
        this.guaranteePeriod = guaranteePeriod == null ? null : guaranteePeriod.trim();
    }

    public String getSaveMethod() {
        return saveMethod;
    }

    public void setSaveMethod(String saveMethod) {
        this.saveMethod = saveMethod == null ? null : saveMethod.trim();
    }

    public String getVariety() {
        return variety;
    }

    public void setVariety(String variety) {
        this.variety = variety == null ? null : variety.trim();
    }

    public String getSalesType() {
        return salesType;
    }

    public void setSalesType(String salesType) {
        this.salesType = salesType == null ? null : salesType.trim();
    }

    public BigDecimal getToken() {
        return token;
    }

    public void setToken(BigDecimal token) {
        this.token = token;
    }

    public String getPacking() {
        return packing;
    }

    public void setPacking(String packing) {
        this.packing = packing == null ? null : packing.trim();
    }

    public String getGroupUrl() {
        return groupUrl;
    }

    public void setGroupUrl(String groupUrl) {
        this.groupUrl = groupUrl == null ? null : groupUrl.trim();
    }

    public Integer getSort() {
        return sort;
    }

    public void setSort(Integer sort) {
        this.sort = sort;
    }

    public String getIsGiftsbuy() {
        return isGiftsbuy;
    }

    public void setIsGiftsbuy(String isGiftsbuy) {
        this.isGiftsbuy = isGiftsbuy == null ? null : isGiftsbuy.trim();
    }

    public String getBusinessId() {
        return businessId;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId == null ? null : businessId.trim();
    }

    public String getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(String categoryId) {
        this.categoryId = categoryId == null ? null : categoryId.trim();
    }

    public String getMinBuyNum() {
        return minBuyNum;
    }

    public void setMinBuyNum(String minBuyNum) {
        this.minBuyNum = minBuyNum == null ? null : minBuyNum.trim();
    }

    public String getIsMonthCommodity() {
        return isMonthCommodity;
    }

    public void setIsMonthCommodity(String isMonthCommodity) {
        this.isMonthCommodity = isMonthCommodity == null ? null : isMonthCommodity.trim();
    }

    public String getIsMonthRandom() {
        return isMonthRandom;
    }

    public void setIsMonthRandom(String isMonthRandom) {
        this.isMonthRandom = isMonthRandom == null ? null : isMonthRandom.trim();
    }

    public Integer getMonthCommodityNum() {
        return monthCommodityNum;
    }

    public void setMonthCommodityNum(Integer monthCommodityNum) {
        this.monthCommodityNum = monthCommodityNum;
    }

    public String getIsCustomizationCommodity() {
        return isCustomizationCommodity;
    }

    public void setIsCustomizationCommodity(String isCustomizationCommodity) {
        this.isCustomizationCommodity = isCustomizationCommodity == null ? null : isCustomizationCommodity.trim();
    }

    public String getIconType() {
        return iconType;
    }

    public void setIconType(String iconType) {
        this.iconType = iconType == null ? null : iconType.trim();
    }

    public Integer getCustomizationNum() {
        return customizationNum;
    }

    public void setCustomizationNum(Integer customizationNum) {
        this.customizationNum = customizationNum;
    }

    public String getDetailState() {
        return detailState;
    }

    public void setDetailState(String detailState) {
        this.detailState = detailState == null ? null : detailState.trim();
    }

    public String getDetailType() {
        return detailType;
    }

    public void setDetailType(String detailType) {
        this.detailType = detailType == null ? null : detailType.trim();
    }

    public String getIsCooperation() {
        return isCooperation;
    }

    public void setIsCooperation(String isCooperation) {
        this.isCooperation = isCooperation == null ? null : isCooperation.trim();
    }

    public String getPlatformType() {
        return platformType;
    }

    public void setPlatformType(String platformType) {
        this.platformType = platformType == null ? null : platformType.trim();
    }

    public String getUprightUrl() {
        return uprightUrl;
    }

    public void setUprightUrl(String uprightUrl) {
        this.uprightUrl = uprightUrl == null ? null : uprightUrl.trim();
    }

    public Integer getLimitNum() {
        return limitNum;
    }

    public void setLimitNum(Integer limitNum) {
        this.limitNum = limitNum;
    }

    public String getShareUrl() {
        return shareUrl;
    }

    public void setShareUrl(String shareUrl) {
        this.shareUrl = shareUrl == null ? null : shareUrl.trim();
    }
}
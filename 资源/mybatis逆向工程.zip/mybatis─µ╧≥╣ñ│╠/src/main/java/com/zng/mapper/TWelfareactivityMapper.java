package com.zng.mapper;

import com.zng.model.TWelfareactivity;

public interface TWelfareactivityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TWelfareactivity record);

    int insertSelective(TWelfareactivity record);

    TWelfareactivity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TWelfareactivity record);

    int updateByPrimaryKey(TWelfareactivity record);
}
package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TAchievement implements Serializable {
    private String id;

    private BigDecimal zng;

    private String achievementTodayZng;

    private BigDecimal certificationValue;

    private String regiment;

    private String regimentUser;

    private String tontruInvitation;

    private String secondInvitation;

    private BigDecimal teamPerformanceZng;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String bond;

    private String regionId;

    private String tokenState;

    private Integer dicision;

    private Integer score;

    private Integer denominatorDay;

    private BigDecimal numeratorSum;

    private Integer remainDays;

    private Integer scoreDays;

    private Integer upfiveDays;

    private Integer first;

    private BigDecimal myPerformance;

    private BigDecimal allPerformance;

    private BigDecimal allNewPerformance;

    private Integer myNum;

    private Integer allNum;

    private Double totalSum;

    private BigDecimal myNewPerformance;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getZng() {
        return zng;
    }

    public void setZng(BigDecimal zng) {
        this.zng = zng;
    }

    public String getAchievementTodayZng() {
        return achievementTodayZng;
    }

    public void setAchievementTodayZng(String achievementTodayZng) {
        this.achievementTodayZng = achievementTodayZng == null ? null : achievementTodayZng.trim();
    }

    public BigDecimal getCertificationValue() {
        return certificationValue;
    }

    public void setCertificationValue(BigDecimal certificationValue) {
        this.certificationValue = certificationValue;
    }

    public String getRegiment() {
        return regiment;
    }

    public void setRegiment(String regiment) {
        this.regiment = regiment == null ? null : regiment.trim();
    }

    public String getRegimentUser() {
        return regimentUser;
    }

    public void setRegimentUser(String regimentUser) {
        this.regimentUser = regimentUser == null ? null : regimentUser.trim();
    }

    public String getTontruInvitation() {
        return tontruInvitation;
    }

    public void setTontruInvitation(String tontruInvitation) {
        this.tontruInvitation = tontruInvitation == null ? null : tontruInvitation.trim();
    }

    public String getSecondInvitation() {
        return secondInvitation;
    }

    public void setSecondInvitation(String secondInvitation) {
        this.secondInvitation = secondInvitation == null ? null : secondInvitation.trim();
    }

    public BigDecimal getTeamPerformanceZng() {
        return teamPerformanceZng;
    }

    public void setTeamPerformanceZng(BigDecimal teamPerformanceZng) {
        this.teamPerformanceZng = teamPerformanceZng;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getBond() {
        return bond;
    }

    public void setBond(String bond) {
        this.bond = bond == null ? null : bond.trim();
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId == null ? null : regionId.trim();
    }

    public String getTokenState() {
        return tokenState;
    }

    public void setTokenState(String tokenState) {
        this.tokenState = tokenState == null ? null : tokenState.trim();
    }

    public Integer getDicision() {
        return dicision;
    }

    public void setDicision(Integer dicision) {
        this.dicision = dicision;
    }

    public Integer getScore() {
        return score;
    }

    public void setScore(Integer score) {
        this.score = score;
    }

    public Integer getDenominatorDay() {
        return denominatorDay;
    }

    public void setDenominatorDay(Integer denominatorDay) {
        this.denominatorDay = denominatorDay;
    }

    public BigDecimal getNumeratorSum() {
        return numeratorSum;
    }

    public void setNumeratorSum(BigDecimal numeratorSum) {
        this.numeratorSum = numeratorSum;
    }

    public Integer getRemainDays() {
        return remainDays;
    }

    public void setRemainDays(Integer remainDays) {
        this.remainDays = remainDays;
    }

    public Integer getScoreDays() {
        return scoreDays;
    }

    public void setScoreDays(Integer scoreDays) {
        this.scoreDays = scoreDays;
    }

    public Integer getUpfiveDays() {
        return upfiveDays;
    }

    public void setUpfiveDays(Integer upfiveDays) {
        this.upfiveDays = upfiveDays;
    }

    public Integer getFirst() {
        return first;
    }

    public void setFirst(Integer first) {
        this.first = first;
    }

    public BigDecimal getMyPerformance() {
        return myPerformance;
    }

    public void setMyPerformance(BigDecimal myPerformance) {
        this.myPerformance = myPerformance;
    }

    public BigDecimal getAllPerformance() {
        return allPerformance;
    }

    public void setAllPerformance(BigDecimal allPerformance) {
        this.allPerformance = allPerformance;
    }

    public BigDecimal getAllNewPerformance() {
        return allNewPerformance;
    }

    public void setAllNewPerformance(BigDecimal allNewPerformance) {
        this.allNewPerformance = allNewPerformance;
    }

    public Integer getMyNum() {
        return myNum;
    }

    public void setMyNum(Integer myNum) {
        this.myNum = myNum;
    }

    public Integer getAllNum() {
        return allNum;
    }

    public void setAllNum(Integer allNum) {
        this.allNum = allNum;
    }

    public Double getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(Double totalSum) {
        this.totalSum = totalSum;
    }

    public BigDecimal getMyNewPerformance() {
        return myNewPerformance;
    }

    public void setMyNewPerformance(BigDecimal myNewPerformance) {
        this.myNewPerformance = myNewPerformance;
    }
}
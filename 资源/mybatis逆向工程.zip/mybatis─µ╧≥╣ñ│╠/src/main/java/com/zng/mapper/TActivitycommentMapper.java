package com.zng.mapper;

import com.zng.model.TActivitycomment;

public interface TActivitycommentMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivitycomment record);

    int insertSelective(TActivitycomment record);

    TActivitycomment selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivitycomment record);

    int updateByPrimaryKey(TActivitycomment record);
}
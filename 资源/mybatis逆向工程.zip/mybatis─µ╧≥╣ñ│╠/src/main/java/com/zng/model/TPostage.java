package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TPostage implements Serializable {
    private String id;

    private String businessId;

    private String province;

    private BigDecimal postage;

    private String state;

    private String createTime;

    private String updateTime;

    private String commodityId;

    private Integer number;

    private Integer reachNum;

    private BigDecimal reachnumPostage;

    private String sendState;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getBusinessId() {
        return businessId;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId == null ? null : businessId.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public BigDecimal getPostage() {
        return postage;
    }

    public void setPostage(BigDecimal postage) {
        this.postage = postage;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getCommodityId() {
        return commodityId;
    }

    public void setCommodityId(String commodityId) {
        this.commodityId = commodityId == null ? null : commodityId.trim();
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public Integer getReachNum() {
        return reachNum;
    }

    public void setReachNum(Integer reachNum) {
        this.reachNum = reachNum;
    }

    public BigDecimal getReachnumPostage() {
        return reachnumPostage;
    }

    public void setReachnumPostage(BigDecimal reachnumPostage) {
        this.reachnumPostage = reachnumPostage;
    }

    public String getSendState() {
        return sendState;
    }

    public void setSendState(String sendState) {
        this.sendState = sendState == null ? null : sendState.trim();
    }
}
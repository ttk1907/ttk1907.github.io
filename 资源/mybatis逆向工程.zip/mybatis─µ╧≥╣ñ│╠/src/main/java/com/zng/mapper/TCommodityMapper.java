package com.zng.mapper;

import com.zng.model.TCommodity;

public interface TCommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommodity record);

    int insertSelective(TCommodity record);

    TCommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommodity record);

    int updateByPrimaryKey(TCommodity record);
}
package com.zng.mapper;

import com.zng.model.TParentorder;

public interface TParentorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TParentorder record);

    int insertSelective(TParentorder record);

    TParentorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TParentorder record);

    int updateByPrimaryKey(TParentorder record);
}
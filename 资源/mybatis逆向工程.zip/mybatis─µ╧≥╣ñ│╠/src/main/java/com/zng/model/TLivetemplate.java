package com.zng.model;

import java.io.Serializable;

public class TLivetemplate implements Serializable {
    private String id;

    private String state;

    private String createTime;

    private String updateTime;

    private String mcnRate;

    private String doctorsRate;

    private String anchorRate;

    private String groupLeaderRate;

    private String consumerRate;

    private String title;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getMcnRate() {
        return mcnRate;
    }

    public void setMcnRate(String mcnRate) {
        this.mcnRate = mcnRate == null ? null : mcnRate.trim();
    }

    public String getDoctorsRate() {
        return doctorsRate;
    }

    public void setDoctorsRate(String doctorsRate) {
        this.doctorsRate = doctorsRate == null ? null : doctorsRate.trim();
    }

    public String getAnchorRate() {
        return anchorRate;
    }

    public void setAnchorRate(String anchorRate) {
        this.anchorRate = anchorRate == null ? null : anchorRate.trim();
    }

    public String getGroupLeaderRate() {
        return groupLeaderRate;
    }

    public void setGroupLeaderRate(String groupLeaderRate) {
        this.groupLeaderRate = groupLeaderRate == null ? null : groupLeaderRate.trim();
    }

    public String getConsumerRate() {
        return consumerRate;
    }

    public void setConsumerRate(String consumerRate) {
        this.consumerRate = consumerRate == null ? null : consumerRate.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }
}
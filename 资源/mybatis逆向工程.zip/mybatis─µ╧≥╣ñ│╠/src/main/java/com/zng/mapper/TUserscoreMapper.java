package com.zng.mapper;

import com.zng.model.TUserscore;

public interface TUserscoreMapper {
    int deleteByPrimaryKey(String id);

    int insert(TUserscore record);

    int insertSelective(TUserscore record);

    TUserscore selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TUserscore record);

    int updateByPrimaryKey(TUserscore record);
}
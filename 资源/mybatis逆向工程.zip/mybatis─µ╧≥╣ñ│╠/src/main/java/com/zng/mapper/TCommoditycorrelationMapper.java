package com.zng.mapper;

import com.zng.model.TCommoditycorrelation;

public interface TCommoditycorrelationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommoditycorrelation record);

    int insertSelective(TCommoditycorrelation record);

    TCommoditycorrelation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommoditycorrelation record);

    int updateByPrimaryKey(TCommoditycorrelation record);
}
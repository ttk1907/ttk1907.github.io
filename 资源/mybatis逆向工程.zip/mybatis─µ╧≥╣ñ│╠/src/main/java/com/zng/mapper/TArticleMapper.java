package com.zng.mapper;

import com.zng.model.TArticle;

public interface TArticleMapper {
    int deleteByPrimaryKey(String id);

    int insert(TArticle record);

    int insertSelective(TArticle record);

    TArticle selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TArticle record);

    int updateByPrimaryKey(TArticle record);
}
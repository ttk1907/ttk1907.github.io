package com.zng.mapper;

import com.zng.model.TCash;

public interface TCashMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCash record);

    int insertSelective(TCash record);

    TCash selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCash record);

    int updateByPrimaryKey(TCash record);
}
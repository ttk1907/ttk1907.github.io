package com.zng.model;

import java.io.Serializable;

public class TEnterpriseclass implements Serializable {
    private String id;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String type;

    private String peopleNumber;

    private String area;

    private String areaId;

    private String nowNumber;

    private String beginTime;

    private String endTime;

    private String title;

    private String role;

    private String groupQrcode;

    private String liveQrcode;

    private String areaDetails;

    private String classDetails;

    private String classImgurl;

    private String temporary;

    private String joinOff;

    private String tutorId;

    private String roomId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getPeopleNumber() {
        return peopleNumber;
    }

    public void setPeopleNumber(String peopleNumber) {
        this.peopleNumber = peopleNumber == null ? null : peopleNumber.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId == null ? null : areaId.trim();
    }

    public String getNowNumber() {
        return nowNumber;
    }

    public void setNowNumber(String nowNumber) {
        this.nowNumber = nowNumber == null ? null : nowNumber.trim();
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime == null ? null : beginTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    public String getGroupQrcode() {
        return groupQrcode;
    }

    public void setGroupQrcode(String groupQrcode) {
        this.groupQrcode = groupQrcode == null ? null : groupQrcode.trim();
    }

    public String getLiveQrcode() {
        return liveQrcode;
    }

    public void setLiveQrcode(String liveQrcode) {
        this.liveQrcode = liveQrcode == null ? null : liveQrcode.trim();
    }

    public String getAreaDetails() {
        return areaDetails;
    }

    public void setAreaDetails(String areaDetails) {
        this.areaDetails = areaDetails == null ? null : areaDetails.trim();
    }

    public String getClassDetails() {
        return classDetails;
    }

    public void setClassDetails(String classDetails) {
        this.classDetails = classDetails == null ? null : classDetails.trim();
    }

    public String getClassImgurl() {
        return classImgurl;
    }

    public void setClassImgurl(String classImgurl) {
        this.classImgurl = classImgurl == null ? null : classImgurl.trim();
    }

    public String getTemporary() {
        return temporary;
    }

    public void setTemporary(String temporary) {
        this.temporary = temporary == null ? null : temporary.trim();
    }

    public String getJoinOff() {
        return joinOff;
    }

    public void setJoinOff(String joinOff) {
        this.joinOff = joinOff == null ? null : joinOff.trim();
    }

    public String getTutorId() {
        return tutorId;
    }

    public void setTutorId(String tutorId) {
        this.tutorId = tutorId == null ? null : tutorId.trim();
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId == null ? null : roomId.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TCategory;

public interface TCategoryMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCategory record);

    int insertSelective(TCategory record);

    TCategory selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCategory record);

    int updateByPrimaryKey(TCategory record);
}
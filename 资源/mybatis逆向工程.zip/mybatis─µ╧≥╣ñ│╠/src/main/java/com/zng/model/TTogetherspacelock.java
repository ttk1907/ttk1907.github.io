package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TTogetherspacelock implements Serializable {
    private String id;

    private String loginId;

    private String createTime;

    private String updateTime;

    private String state;

    private String cityName;

    private String cityId;

    private BigDecimal money;

    private String startTime;

    private String endTime;

    private BigDecimal targetPerformance;

    private BigDecimal currentPerformance;

    private String togetherSpaceId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName == null ? null : cityName.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime == null ? null : startTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public BigDecimal getTargetPerformance() {
        return targetPerformance;
    }

    public void setTargetPerformance(BigDecimal targetPerformance) {
        this.targetPerformance = targetPerformance;
    }

    public BigDecimal getCurrentPerformance() {
        return currentPerformance;
    }

    public void setCurrentPerformance(BigDecimal currentPerformance) {
        this.currentPerformance = currentPerformance;
    }

    public String getTogetherSpaceId() {
        return togetherSpaceId;
    }

    public void setTogetherSpaceId(String togetherSpaceId) {
        this.togetherSpaceId = togetherSpaceId == null ? null : togetherSpaceId.trim();
    }
}
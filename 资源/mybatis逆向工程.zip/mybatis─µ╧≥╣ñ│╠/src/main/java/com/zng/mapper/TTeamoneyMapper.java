package com.zng.mapper;

import com.zng.model.TTeamoney;

public interface TTeamoneyMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTeamoney record);

    int insertSelective(TTeamoney record);

    TTeamoney selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTeamoney record);

    int updateByPrimaryKey(TTeamoney record);
}
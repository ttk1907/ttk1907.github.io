package com.zng.mapper;

import com.zng.model.TClasssigninformation;

public interface TClasssigninformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TClasssigninformation record);

    int insertSelective(TClasssigninformation record);

    TClasssigninformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TClasssigninformation record);

    int updateByPrimaryKey(TClasssigninformation record);
}
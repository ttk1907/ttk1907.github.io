package com.zng.mapper;

import com.zng.model.TPledgeorder;

public interface TPledgeorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TPledgeorder record);

    int insertSelective(TPledgeorder record);

    TPledgeorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TPledgeorder record);

    int updateByPrimaryKey(TPledgeorder record);
}
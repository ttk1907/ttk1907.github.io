package com.zng.mapper;

import com.zng.model.TGiftsbuyteam;

public interface TGiftsbuyteamMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGiftsbuyteam record);

    int insertSelective(TGiftsbuyteam record);

    TGiftsbuyteam selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGiftsbuyteam record);

    int updateByPrimaryKey(TGiftsbuyteam record);
}
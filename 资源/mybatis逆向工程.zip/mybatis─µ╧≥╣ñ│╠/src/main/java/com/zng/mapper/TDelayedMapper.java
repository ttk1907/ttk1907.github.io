package com.zng.mapper;

import com.zng.model.TDelayed;

public interface TDelayedMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDelayed record);

    int insertSelective(TDelayed record);

    TDelayed selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDelayed record);

    int updateByPrimaryKey(TDelayed record);
}
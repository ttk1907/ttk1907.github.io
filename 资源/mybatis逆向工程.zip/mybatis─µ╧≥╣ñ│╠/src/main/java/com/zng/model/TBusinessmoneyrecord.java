package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TBusinessmoneyrecord implements Serializable {
    private String id;

    private BigDecimal money;

    private String orderId;

    private String createTime;

    private String updateTime;

    private String state;

    private String arrearsBusinessName;

    private String arrearsBusinessId;

    private String creditorBusinessName;

    private String creditorBusinessId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getArrearsBusinessName() {
        return arrearsBusinessName;
    }

    public void setArrearsBusinessName(String arrearsBusinessName) {
        this.arrearsBusinessName = arrearsBusinessName == null ? null : arrearsBusinessName.trim();
    }

    public String getArrearsBusinessId() {
        return arrearsBusinessId;
    }

    public void setArrearsBusinessId(String arrearsBusinessId) {
        this.arrearsBusinessId = arrearsBusinessId == null ? null : arrearsBusinessId.trim();
    }

    public String getCreditorBusinessName() {
        return creditorBusinessName;
    }

    public void setCreditorBusinessName(String creditorBusinessName) {
        this.creditorBusinessName = creditorBusinessName == null ? null : creditorBusinessName.trim();
    }

    public String getCreditorBusinessId() {
        return creditorBusinessId;
    }

    public void setCreditorBusinessId(String creditorBusinessId) {
        this.creditorBusinessId = creditorBusinessId == null ? null : creditorBusinessId.trim();
    }
}
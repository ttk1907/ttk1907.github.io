package com.zng.mapper;

import com.zng.model.TCrossbordercommodity;

public interface TCrossbordercommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCrossbordercommodity record);

    int insertSelective(TCrossbordercommodity record);

    TCrossbordercommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCrossbordercommodity record);

    int updateByPrimaryKey(TCrossbordercommodity record);
}
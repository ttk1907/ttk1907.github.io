package com.zng.mapper;

import com.zng.model.TEnterpriseclass;

public interface TEnterpriseclassMapper {
    int deleteByPrimaryKey(String id);

    int insert(TEnterpriseclass record);

    int insertSelective(TEnterpriseclass record);

    TEnterpriseclass selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TEnterpriseclass record);

    int updateByPrimaryKey(TEnterpriseclass record);
}
package com.zng.mapper;

import com.zng.model.TInvoicetemplate;

public interface TInvoicetemplateMapper {
    int deleteByPrimaryKey(String id);

    int insert(TInvoicetemplate record);

    int insertSelective(TInvoicetemplate record);

    TInvoicetemplate selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TInvoicetemplate record);

    int updateByPrimaryKey(TInvoicetemplate record);
}
package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class TBonus implements Serializable {
    private String id;

    private BigDecimal zng;

    private String createLoginId;

    private String state;

    private Date createTime;

    private Date updateTime;

    private String area;

    private String orderId;

    private String type;

    private String classOrderId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getZng() {
        return zng;
    }

    public void setZng(BigDecimal zng) {
        this.zng = zng;
    }

    public String getCreateLoginId() {
        return createLoginId;
    }

    public void setCreateLoginId(String createLoginId) {
        this.createLoginId = createLoginId == null ? null : createLoginId.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId == null ? null : orderId.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getClassOrderId() {
        return classOrderId;
    }

    public void setClassOrderId(String classOrderId) {
        this.classOrderId = classOrderId == null ? null : classOrderId.trim();
    }
}
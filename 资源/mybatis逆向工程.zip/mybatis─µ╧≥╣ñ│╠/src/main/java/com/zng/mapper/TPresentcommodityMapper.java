package com.zng.mapper;

import com.zng.model.TPresentcommodity;

public interface TPresentcommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TPresentcommodity record);

    int insertSelective(TPresentcommodity record);

    TPresentcommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TPresentcommodity record);

    int updateByPrimaryKey(TPresentcommodity record);
}
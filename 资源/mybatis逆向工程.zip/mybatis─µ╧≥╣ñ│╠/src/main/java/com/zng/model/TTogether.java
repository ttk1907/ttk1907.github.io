package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TTogether implements Serializable {
    private String id;

    private BigDecimal token;

    private BigDecimal tokenRecord;

    private BigDecimal zngRecord;

    private Integer regimentGrade;

    private Integer regimentTotalNum;

    private Integer regimentSubordinateNum;

    private BigDecimal totalPerformance;

    private BigDecimal threePerformance;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String area;

    private String name;

    private String idCard;

    private String upUrl;

    private String regionId;

    private String downUrl;

    private String phone;

    private BigDecimal waitToken;

    private BigDecimal waitZng;

    private String power;

    private String medalLogin;

    private String scoreMedal;

    private String peopleMedal;

    private String moneyMedal;

    private String authenticationTime;

    private String firstMatching;

    private String secondMatching;

    private String location;

    private String resources;

    private String goodAt;

    private String mind;

    private String experience;

    private String role;

    private String workArea;

    private String togetherId;

    private Integer whether;

    private String togetherTime;

    private String address;

    private String birthday;

    private String sex;

    private String nation;

    private String expiration;

    private Integer highestRegimentGrade;

    private String gradePermission;

    private String pinyin;

    private String togetherBuyState;

    private String upgradeTime;

    private String viscountState;

    private String excellenceState;

    private String downgradeTime;

    private String payState;

    private BigDecimal lockToken;

    private String averagePrice;

    private String bigHeroState;

    private Integer lineHighestGrade;

    private BigDecimal previousToken;

    private BigDecimal monthBuyLock;

    private String monthBuyTime;

    private Integer monthBuyNum;

    private BigDecimal monthBuyMoney;

    private BigDecimal unlockExcitationNum;

    private String lastUpgradeTime;

    private String isTogetherWelfare;

    private String isNanWelfare;

    private BigDecimal customizationBuyMoney;

    private BigDecimal optimizationBuyMoney;

    private Integer customizationNumber;

    private String isActive;

    private BigDecimal newPerformance;

    private BigDecimal mrfLockNum;

    private String isCommunity;

    private BigDecimal nzzCustomizationMoney;

    private BigDecimal nzzOptimizationMoney;

    private Integer nzzCustomizationNumber;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getToken() {
        return token;
    }

    public void setToken(BigDecimal token) {
        this.token = token;
    }

    public BigDecimal getTokenRecord() {
        return tokenRecord;
    }

    public void setTokenRecord(BigDecimal tokenRecord) {
        this.tokenRecord = tokenRecord;
    }

    public BigDecimal getZngRecord() {
        return zngRecord;
    }

    public void setZngRecord(BigDecimal zngRecord) {
        this.zngRecord = zngRecord;
    }

    public Integer getRegimentGrade() {
        return regimentGrade;
    }

    public void setRegimentGrade(Integer regimentGrade) {
        this.regimentGrade = regimentGrade;
    }

    public Integer getRegimentTotalNum() {
        return regimentTotalNum;
    }

    public void setRegimentTotalNum(Integer regimentTotalNum) {
        this.regimentTotalNum = regimentTotalNum;
    }

    public Integer getRegimentSubordinateNum() {
        return regimentSubordinateNum;
    }

    public void setRegimentSubordinateNum(Integer regimentSubordinateNum) {
        this.regimentSubordinateNum = regimentSubordinateNum;
    }

    public BigDecimal getTotalPerformance() {
        return totalPerformance;
    }

    public void setTotalPerformance(BigDecimal totalPerformance) {
        this.totalPerformance = totalPerformance;
    }

    public BigDecimal getThreePerformance() {
        return threePerformance;
    }

    public void setThreePerformance(BigDecimal threePerformance) {
        this.threePerformance = threePerformance;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard == null ? null : idCard.trim();
    }

    public String getUpUrl() {
        return upUrl;
    }

    public void setUpUrl(String upUrl) {
        this.upUrl = upUrl == null ? null : upUrl.trim();
    }

    public String getRegionId() {
        return regionId;
    }

    public void setRegionId(String regionId) {
        this.regionId = regionId == null ? null : regionId.trim();
    }

    public String getDownUrl() {
        return downUrl;
    }

    public void setDownUrl(String downUrl) {
        this.downUrl = downUrl == null ? null : downUrl.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public BigDecimal getWaitToken() {
        return waitToken;
    }

    public void setWaitToken(BigDecimal waitToken) {
        this.waitToken = waitToken;
    }

    public BigDecimal getWaitZng() {
        return waitZng;
    }

    public void setWaitZng(BigDecimal waitZng) {
        this.waitZng = waitZng;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power == null ? null : power.trim();
    }

    public String getMedalLogin() {
        return medalLogin;
    }

    public void setMedalLogin(String medalLogin) {
        this.medalLogin = medalLogin == null ? null : medalLogin.trim();
    }

    public String getScoreMedal() {
        return scoreMedal;
    }

    public void setScoreMedal(String scoreMedal) {
        this.scoreMedal = scoreMedal == null ? null : scoreMedal.trim();
    }

    public String getPeopleMedal() {
        return peopleMedal;
    }

    public void setPeopleMedal(String peopleMedal) {
        this.peopleMedal = peopleMedal == null ? null : peopleMedal.trim();
    }

    public String getMoneyMedal() {
        return moneyMedal;
    }

    public void setMoneyMedal(String moneyMedal) {
        this.moneyMedal = moneyMedal == null ? null : moneyMedal.trim();
    }

    public String getAuthenticationTime() {
        return authenticationTime;
    }

    public void setAuthenticationTime(String authenticationTime) {
        this.authenticationTime = authenticationTime == null ? null : authenticationTime.trim();
    }

    public String getFirstMatching() {
        return firstMatching;
    }

    public void setFirstMatching(String firstMatching) {
        this.firstMatching = firstMatching == null ? null : firstMatching.trim();
    }

    public String getSecondMatching() {
        return secondMatching;
    }

    public void setSecondMatching(String secondMatching) {
        this.secondMatching = secondMatching == null ? null : secondMatching.trim();
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location == null ? null : location.trim();
    }

    public String getResources() {
        return resources;
    }

    public void setResources(String resources) {
        this.resources = resources == null ? null : resources.trim();
    }

    public String getGoodAt() {
        return goodAt;
    }

    public void setGoodAt(String goodAt) {
        this.goodAt = goodAt == null ? null : goodAt.trim();
    }

    public String getMind() {
        return mind;
    }

    public void setMind(String mind) {
        this.mind = mind == null ? null : mind.trim();
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience == null ? null : experience.trim();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    public String getWorkArea() {
        return workArea;
    }

    public void setWorkArea(String workArea) {
        this.workArea = workArea == null ? null : workArea.trim();
    }

    public String getTogetherId() {
        return togetherId;
    }

    public void setTogetherId(String togetherId) {
        this.togetherId = togetherId == null ? null : togetherId.trim();
    }

    public Integer getWhether() {
        return whether;
    }

    public void setWhether(Integer whether) {
        this.whether = whether;
    }

    public String getTogetherTime() {
        return togetherTime;
    }

    public void setTogetherTime(String togetherTime) {
        this.togetherTime = togetherTime == null ? null : togetherTime.trim();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday == null ? null : birthday.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation == null ? null : nation.trim();
    }

    public String getExpiration() {
        return expiration;
    }

    public void setExpiration(String expiration) {
        this.expiration = expiration == null ? null : expiration.trim();
    }

    public Integer getHighestRegimentGrade() {
        return highestRegimentGrade;
    }

    public void setHighestRegimentGrade(Integer highestRegimentGrade) {
        this.highestRegimentGrade = highestRegimentGrade;
    }

    public String getGradePermission() {
        return gradePermission;
    }

    public void setGradePermission(String gradePermission) {
        this.gradePermission = gradePermission == null ? null : gradePermission.trim();
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin == null ? null : pinyin.trim();
    }

    public String getTogetherBuyState() {
        return togetherBuyState;
    }

    public void setTogetherBuyState(String togetherBuyState) {
        this.togetherBuyState = togetherBuyState == null ? null : togetherBuyState.trim();
    }

    public String getUpgradeTime() {
        return upgradeTime;
    }

    public void setUpgradeTime(String upgradeTime) {
        this.upgradeTime = upgradeTime == null ? null : upgradeTime.trim();
    }

    public String getViscountState() {
        return viscountState;
    }

    public void setViscountState(String viscountState) {
        this.viscountState = viscountState == null ? null : viscountState.trim();
    }

    public String getExcellenceState() {
        return excellenceState;
    }

    public void setExcellenceState(String excellenceState) {
        this.excellenceState = excellenceState == null ? null : excellenceState.trim();
    }

    public String getDowngradeTime() {
        return downgradeTime;
    }

    public void setDowngradeTime(String downgradeTime) {
        this.downgradeTime = downgradeTime == null ? null : downgradeTime.trim();
    }

    public String getPayState() {
        return payState;
    }

    public void setPayState(String payState) {
        this.payState = payState == null ? null : payState.trim();
    }

    public BigDecimal getLockToken() {
        return lockToken;
    }

    public void setLockToken(BigDecimal lockToken) {
        this.lockToken = lockToken;
    }

    public String getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(String averagePrice) {
        this.averagePrice = averagePrice == null ? null : averagePrice.trim();
    }

    public String getBigHeroState() {
        return bigHeroState;
    }

    public void setBigHeroState(String bigHeroState) {
        this.bigHeroState = bigHeroState == null ? null : bigHeroState.trim();
    }

    public Integer getLineHighestGrade() {
        return lineHighestGrade;
    }

    public void setLineHighestGrade(Integer lineHighestGrade) {
        this.lineHighestGrade = lineHighestGrade;
    }

    public BigDecimal getPreviousToken() {
        return previousToken;
    }

    public void setPreviousToken(BigDecimal previousToken) {
        this.previousToken = previousToken;
    }

    public BigDecimal getMonthBuyLock() {
        return monthBuyLock;
    }

    public void setMonthBuyLock(BigDecimal monthBuyLock) {
        this.monthBuyLock = monthBuyLock;
    }

    public String getMonthBuyTime() {
        return monthBuyTime;
    }

    public void setMonthBuyTime(String monthBuyTime) {
        this.monthBuyTime = monthBuyTime == null ? null : monthBuyTime.trim();
    }

    public Integer getMonthBuyNum() {
        return monthBuyNum;
    }

    public void setMonthBuyNum(Integer monthBuyNum) {
        this.monthBuyNum = monthBuyNum;
    }

    public BigDecimal getMonthBuyMoney() {
        return monthBuyMoney;
    }

    public void setMonthBuyMoney(BigDecimal monthBuyMoney) {
        this.monthBuyMoney = monthBuyMoney;
    }

    public BigDecimal getUnlockExcitationNum() {
        return unlockExcitationNum;
    }

    public void setUnlockExcitationNum(BigDecimal unlockExcitationNum) {
        this.unlockExcitationNum = unlockExcitationNum;
    }

    public String getLastUpgradeTime() {
        return lastUpgradeTime;
    }

    public void setLastUpgradeTime(String lastUpgradeTime) {
        this.lastUpgradeTime = lastUpgradeTime == null ? null : lastUpgradeTime.trim();
    }

    public String getIsTogetherWelfare() {
        return isTogetherWelfare;
    }

    public void setIsTogetherWelfare(String isTogetherWelfare) {
        this.isTogetherWelfare = isTogetherWelfare == null ? null : isTogetherWelfare.trim();
    }

    public String getIsNanWelfare() {
        return isNanWelfare;
    }

    public void setIsNanWelfare(String isNanWelfare) {
        this.isNanWelfare = isNanWelfare == null ? null : isNanWelfare.trim();
    }

    public BigDecimal getCustomizationBuyMoney() {
        return customizationBuyMoney;
    }

    public void setCustomizationBuyMoney(BigDecimal customizationBuyMoney) {
        this.customizationBuyMoney = customizationBuyMoney;
    }

    public BigDecimal getOptimizationBuyMoney() {
        return optimizationBuyMoney;
    }

    public void setOptimizationBuyMoney(BigDecimal optimizationBuyMoney) {
        this.optimizationBuyMoney = optimizationBuyMoney;
    }

    public Integer getCustomizationNumber() {
        return customizationNumber;
    }

    public void setCustomizationNumber(Integer customizationNumber) {
        this.customizationNumber = customizationNumber;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive == null ? null : isActive.trim();
    }

    public BigDecimal getNewPerformance() {
        return newPerformance;
    }

    public void setNewPerformance(BigDecimal newPerformance) {
        this.newPerformance = newPerformance;
    }

    public BigDecimal getMrfLockNum() {
        return mrfLockNum;
    }

    public void setMrfLockNum(BigDecimal mrfLockNum) {
        this.mrfLockNum = mrfLockNum;
    }

    public String getIsCommunity() {
        return isCommunity;
    }

    public void setIsCommunity(String isCommunity) {
        this.isCommunity = isCommunity == null ? null : isCommunity.trim();
    }

    public BigDecimal getNzzCustomizationMoney() {
        return nzzCustomizationMoney;
    }

    public void setNzzCustomizationMoney(BigDecimal nzzCustomizationMoney) {
        this.nzzCustomizationMoney = nzzCustomizationMoney;
    }

    public BigDecimal getNzzOptimizationMoney() {
        return nzzOptimizationMoney;
    }

    public void setNzzOptimizationMoney(BigDecimal nzzOptimizationMoney) {
        this.nzzOptimizationMoney = nzzOptimizationMoney;
    }

    public Integer getNzzCustomizationNumber() {
        return nzzCustomizationNumber;
    }

    public void setNzzCustomizationNumber(Integer nzzCustomizationNumber) {
        this.nzzCustomizationNumber = nzzCustomizationNumber;
    }
}
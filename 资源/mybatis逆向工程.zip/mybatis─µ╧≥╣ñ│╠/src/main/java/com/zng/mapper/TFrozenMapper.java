package com.zng.mapper;

import com.zng.model.TFrozen;

public interface TFrozenMapper {
    int deleteByPrimaryKey(String id);

    int insert(TFrozen record);

    int insertSelective(TFrozen record);

    TFrozen selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TFrozen record);

    int updateByPrimaryKey(TFrozen record);
}
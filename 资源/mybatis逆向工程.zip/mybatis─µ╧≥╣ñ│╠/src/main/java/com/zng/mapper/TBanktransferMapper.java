package com.zng.mapper;

import com.zng.model.TBanktransfer;

public interface TBanktransferMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBanktransfer record);

    int insertSelective(TBanktransfer record);

    TBanktransfer selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBanktransfer record);

    int updateByPrimaryKey(TBanktransfer record);
}
package com.zng.mapper;

import com.zng.model.TCreationcard;

public interface TCreationcardMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCreationcard record);

    int insertSelective(TCreationcard record);

    TCreationcard selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCreationcard record);

    int updateByPrimaryKey(TCreationcard record);
}
package com.zng.mapper;

import com.zng.model.TSystemdays;

public interface TSystemdaysMapper {
    int deleteByPrimaryKey(String id);

    int insert(TSystemdays record);

    int insertSelective(TSystemdays record);

    TSystemdays selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TSystemdays record);

    int updateByPrimaryKey(TSystemdays record);
}
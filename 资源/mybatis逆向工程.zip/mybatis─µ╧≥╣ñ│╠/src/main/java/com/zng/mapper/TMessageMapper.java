package com.zng.mapper;

import com.zng.model.TMessage;

public interface TMessageMapper {
    int deleteByPrimaryKey(String id);

    int insert(TMessage record);

    int insertSelective(TMessage record);

    TMessage selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TMessage record);

    int updateByPrimaryKey(TMessage record);
}
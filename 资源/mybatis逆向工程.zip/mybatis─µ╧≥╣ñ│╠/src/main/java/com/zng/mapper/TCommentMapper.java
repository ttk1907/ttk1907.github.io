package com.zng.mapper;

import com.zng.model.TComment;

public interface TCommentMapper {
    int deleteByPrimaryKey(String id);

    int insert(TComment record);

    int insertSelective(TComment record);

    TComment selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TComment record);

    int updateByPrimaryKeyWithBLOBs(TComment record);

    int updateByPrimaryKey(TComment record);
}
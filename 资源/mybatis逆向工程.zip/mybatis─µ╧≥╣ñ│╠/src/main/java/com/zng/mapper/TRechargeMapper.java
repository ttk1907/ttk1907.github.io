package com.zng.mapper;

import com.zng.model.TRecharge;

public interface TRechargeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRecharge record);

    int insertSelective(TRecharge record);

    TRecharge selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRecharge record);

    int updateByPrimaryKey(TRecharge record);
}
package com.zng.mapper;

import com.zng.model.TTokendetail;

public interface TTokendetailMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTokendetail record);

    int insertSelective(TTokendetail record);

    TTokendetail selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTokendetail record);

    int updateByPrimaryKey(TTokendetail record);
}
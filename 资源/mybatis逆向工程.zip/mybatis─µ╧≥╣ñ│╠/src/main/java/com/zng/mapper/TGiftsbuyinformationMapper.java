package com.zng.mapper;

import com.zng.model.TGiftsbuyinformation;

public interface TGiftsbuyinformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGiftsbuyinformation record);

    int insertSelective(TGiftsbuyinformation record);

    TGiftsbuyinformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGiftsbuyinformation record);

    int updateByPrimaryKey(TGiftsbuyinformation record);
}
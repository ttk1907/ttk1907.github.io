package com.zng.mapper;

import com.zng.model.TTreasure;

public interface TTreasureMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTreasure record);

    int insertSelective(TTreasure record);

    TTreasure selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTreasure record);

    int updateByPrimaryKey(TTreasure record);
}
package com.zng.mapper;

import com.zng.model.TIntegral;

public interface TIntegralMapper {
    int deleteByPrimaryKey(String id);

    int insert(TIntegral record);

    int insertSelective(TIntegral record);

    TIntegral selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TIntegral record);

    int updateByPrimaryKey(TIntegral record);
}
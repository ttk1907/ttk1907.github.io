package com.zng.mapper;

import com.zng.model.TTransaction;

public interface TTransactionMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTransaction record);

    int insertSelective(TTransaction record);

    TTransaction selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTransaction record);

    int updateByPrimaryKey(TTransaction record);
}
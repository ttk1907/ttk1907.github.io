package com.zng.model;

import java.io.Serializable;

public class TAuthentication implements Serializable {
    private String id;

    private String createTime;

    private String updateTime;

    private String cityId;

    private String loginId;

    private String area;

    private String name;

    private String idc;

    private String idcupUrl;

    private String idcdownUrl;

    private String phone;

    private String firstMatching;

    private String secondMatching;

    private String location;

    private String resources;

    private String goodAt;

    private String mind;

    private String advantage;

    private String experience;

    private String role;

    private String state;

    private String payPassword;

    private String code;

    private Long sendTime;

    private String pinyin;

    private String replyId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdc() {
        return idc;
    }

    public void setIdc(String idc) {
        this.idc = idc == null ? null : idc.trim();
    }

    public String getIdcupUrl() {
        return idcupUrl;
    }

    public void setIdcupUrl(String idcupUrl) {
        this.idcupUrl = idcupUrl == null ? null : idcupUrl.trim();
    }

    public String getIdcdownUrl() {
        return idcdownUrl;
    }

    public void setIdcdownUrl(String idcdownUrl) {
        this.idcdownUrl = idcdownUrl == null ? null : idcdownUrl.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getFirstMatching() {
        return firstMatching;
    }

    public void setFirstMatching(String firstMatching) {
        this.firstMatching = firstMatching == null ? null : firstMatching.trim();
    }

    public String getSecondMatching() {
        return secondMatching;
    }

    public void setSecondMatching(String secondMatching) {
        this.secondMatching = secondMatching == null ? null : secondMatching.trim();
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location == null ? null : location.trim();
    }

    public String getResources() {
        return resources;
    }

    public void setResources(String resources) {
        this.resources = resources == null ? null : resources.trim();
    }

    public String getGoodAt() {
        return goodAt;
    }

    public void setGoodAt(String goodAt) {
        this.goodAt = goodAt == null ? null : goodAt.trim();
    }

    public String getMind() {
        return mind;
    }

    public void setMind(String mind) {
        this.mind = mind == null ? null : mind.trim();
    }

    public String getAdvantage() {
        return advantage;
    }

    public void setAdvantage(String advantage) {
        this.advantage = advantage == null ? null : advantage.trim();
    }

    public String getExperience() {
        return experience;
    }

    public void setExperience(String experience) {
        this.experience = experience == null ? null : experience.trim();
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role == null ? null : role.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getPayPassword() {
        return payPassword;
    }

    public void setPayPassword(String payPassword) {
        this.payPassword = payPassword == null ? null : payPassword.trim();
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code == null ? null : code.trim();
    }

    public Long getSendTime() {
        return sendTime;
    }

    public void setSendTime(Long sendTime) {
        this.sendTime = sendTime;
    }

    public String getPinyin() {
        return pinyin;
    }

    public void setPinyin(String pinyin) {
        this.pinyin = pinyin == null ? null : pinyin.trim();
    }

    public String getReplyId() {
        return replyId;
    }

    public void setReplyId(String replyId) {
        this.replyId = replyId == null ? null : replyId.trim();
    }
}
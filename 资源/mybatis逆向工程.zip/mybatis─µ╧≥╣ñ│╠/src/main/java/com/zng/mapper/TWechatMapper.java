package com.zng.mapper;

import com.zng.model.TWechat;

public interface TWechatMapper {
    int deleteByPrimaryKey(String id);

    int insert(TWechat record);

    int insertSelective(TWechat record);

    TWechat selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TWechat record);

    int updateByPrimaryKey(TWechat record);
}
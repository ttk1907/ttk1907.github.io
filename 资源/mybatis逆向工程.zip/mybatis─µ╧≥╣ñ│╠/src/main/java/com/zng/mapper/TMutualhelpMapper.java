package com.zng.mapper;

import com.zng.model.TMutualhelp;

public interface TMutualhelpMapper {
    int deleteByPrimaryKey(String id);

    int insert(TMutualhelp record);

    int insertSelective(TMutualhelp record);

    TMutualhelp selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TMutualhelp record);

    int updateByPrimaryKey(TMutualhelp record);
}
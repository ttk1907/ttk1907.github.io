package com.zng.mapper;

import com.zng.model.TBonus;

public interface TBonusMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBonus record);

    int insertSelective(TBonus record);

    TBonus selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBonus record);

    int updateByPrimaryKey(TBonus record);
}
package com.zng.model;

import java.io.Serializable;

public class TStatistics implements Serializable {
    private String id;

    private String sum;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String totalSum;

    private String totalMoneyLogin;

    private String totalMoney;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getSum() {
        return sum;
    }

    public void setSum(String sum) {
        this.sum = sum == null ? null : sum.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(String totalSum) {
        this.totalSum = totalSum == null ? null : totalSum.trim();
    }

    public String getTotalMoneyLogin() {
        return totalMoneyLogin;
    }

    public void setTotalMoneyLogin(String totalMoneyLogin) {
        this.totalMoneyLogin = totalMoneyLogin == null ? null : totalMoneyLogin.trim();
    }

    public String getTotalMoney() {
        return totalMoney;
    }

    public void setTotalMoney(String totalMoney) {
        this.totalMoney = totalMoney == null ? null : totalMoney.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TMedicaldatadirectory;

public interface TMedicaldatadirectoryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TMedicaldatadirectory record);

    int insertSelective(TMedicaldatadirectory record);

    TMedicaldatadirectory selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TMedicaldatadirectory record);

    int updateByPrimaryKey(TMedicaldatadirectory record);
}
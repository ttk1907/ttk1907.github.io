package com.zng.mapper;

import com.zng.model.TJoinitem;

public interface TJoinitemMapper {
    int deleteByPrimaryKey(String id);

    int insert(TJoinitem record);

    int insertSelective(TJoinitem record);

    TJoinitem selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TJoinitem record);

    int updateByPrimaryKey(TJoinitem record);
}
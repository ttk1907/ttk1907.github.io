package com.zng.mapper;

import com.zng.model.TCashout;

public interface TCashoutMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCashout record);

    int insertSelective(TCashout record);

    TCashout selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCashout record);

    int updateByPrimaryKey(TCashout record);
}
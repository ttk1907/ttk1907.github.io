package com.zng.mapper;

import com.zng.model.TTeamitem;

public interface TTeamitemMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTeamitem record);

    int insertSelective(TTeamitem record);

    TTeamitem selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTeamitem record);

    int updateByPrimaryKey(TTeamitem record);
}
package com.zng.mapper;

import com.zng.model.TAuthenticationaudit;

public interface TAuthenticationauditMapper {
    int deleteByPrimaryKey(String id);

    int insert(TAuthenticationaudit record);

    int insertSelective(TAuthenticationaudit record);

    TAuthenticationaudit selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TAuthenticationaudit record);

    int updateByPrimaryKey(TAuthenticationaudit record);
}
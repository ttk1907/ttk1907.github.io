package com.zng.mapper;

import com.zng.model.TTogetherorder;

public interface TTogetherorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogetherorder record);

    int insertSelective(TTogetherorder record);

    TTogetherorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogetherorder record);

    int updateByPrimaryKey(TTogetherorder record);
}
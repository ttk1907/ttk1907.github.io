package com.zng.mapper;

import com.zng.model.TGiftsbuy;

public interface TGiftsbuyMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGiftsbuy record);

    int insertSelective(TGiftsbuy record);

    TGiftsbuy selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGiftsbuy record);

    int updateByPrimaryKey(TGiftsbuy record);
}
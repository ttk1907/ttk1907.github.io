package com.zng.mapper;

import com.zng.model.TItemreview;

public interface TItemreviewMapper {
    int deleteByPrimaryKey(String id);

    int insert(TItemreview record);

    int insertSelective(TItemreview record);

    TItemreview selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TItemreview record);

    int updateByPrimaryKey(TItemreview record);
}
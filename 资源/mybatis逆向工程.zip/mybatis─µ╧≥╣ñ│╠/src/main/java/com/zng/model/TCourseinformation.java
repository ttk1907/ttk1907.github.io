package com.zng.model;

import java.io.Serializable;

public class TCourseinformation implements Serializable {
    private String id;

    private String loginId;

    private String state;

    private String createTime;

    private String updateTime;

    private String type;

    private String title;

    private String detail;

    private String area;

    private String areaId;

    private String beginTime;

    private String endTime;

    private String areaDetails;

    private String classImgurl;

    private String provinceId;

    private String theme;

    private String themeImgurl;

    private String committeePhone;

    private String presidePhone;

    private String cateringPhone;

    private String profitState;

    private String themeId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title == null ? null : title.trim();
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail == null ? null : detail.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId == null ? null : areaId.trim();
    }

    public String getBeginTime() {
        return beginTime;
    }

    public void setBeginTime(String beginTime) {
        this.beginTime = beginTime == null ? null : beginTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public String getAreaDetails() {
        return areaDetails;
    }

    public void setAreaDetails(String areaDetails) {
        this.areaDetails = areaDetails == null ? null : areaDetails.trim();
    }

    public String getClassImgurl() {
        return classImgurl;
    }

    public void setClassImgurl(String classImgurl) {
        this.classImgurl = classImgurl == null ? null : classImgurl.trim();
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId == null ? null : provinceId.trim();
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme == null ? null : theme.trim();
    }

    public String getThemeImgurl() {
        return themeImgurl;
    }

    public void setThemeImgurl(String themeImgurl) {
        this.themeImgurl = themeImgurl == null ? null : themeImgurl.trim();
    }

    public String getCommitteePhone() {
        return committeePhone;
    }

    public void setCommitteePhone(String committeePhone) {
        this.committeePhone = committeePhone == null ? null : committeePhone.trim();
    }

    public String getPresidePhone() {
        return presidePhone;
    }

    public void setPresidePhone(String presidePhone) {
        this.presidePhone = presidePhone == null ? null : presidePhone.trim();
    }

    public String getCateringPhone() {
        return cateringPhone;
    }

    public void setCateringPhone(String cateringPhone) {
        this.cateringPhone = cateringPhone == null ? null : cateringPhone.trim();
    }

    public String getProfitState() {
        return profitState;
    }

    public void setProfitState(String profitState) {
        this.profitState = profitState == null ? null : profitState.trim();
    }

    public String getThemeId() {
        return themeId;
    }

    public void setThemeId(String themeId) {
        this.themeId = themeId == null ? null : themeId.trim();
    }
}
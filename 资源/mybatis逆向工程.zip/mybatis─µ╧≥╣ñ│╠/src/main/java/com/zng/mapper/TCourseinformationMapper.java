package com.zng.mapper;

import com.zng.model.TCourseinformation;

public interface TCourseinformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCourseinformation record);

    int insertSelective(TCourseinformation record);

    TCourseinformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCourseinformation record);

    int updateByPrimaryKey(TCourseinformation record);
}
package com.zng.model;

import java.io.Serializable;

public class TProductsapplication implements Serializable {
    private String id;

    private String selectionName;

    private String selectionPhone;

    private String recommendTime;

    private String supplierCondition;

    private String sampleCondition;

    private String companyName;

    private String companyAddress;

    private String personName;

    private String companyContacts;

    private String contactsTelephone;

    private String contactsPhone;

    private String registeredCapital;

    private String establishTime;

    private String businessContacts;

    private String contactsEmail;

    private String bankInformation;

    private String companyAccount;

    private String taxNumber;

    private String peopleCapacity;

    private String businessScope;

    private String licenseImageurl;

    private String organizationImageurl;

    private String registerImageurl;

    private String reportImageurl;

    private String productName;

    private String productCategory;

    private String productBurden;

    private String contentPabulum;

    private String stockpileWayandtime;

    private String productNumber;

    private String permitNumber;

    private String productSpecialty;

    private String productRemark;

    private String productUrl;

    private String state;

    private String createTime;

    private String updateTime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getSelectionName() {
        return selectionName;
    }

    public void setSelectionName(String selectionName) {
        this.selectionName = selectionName == null ? null : selectionName.trim();
    }

    public String getSelectionPhone() {
        return selectionPhone;
    }

    public void setSelectionPhone(String selectionPhone) {
        this.selectionPhone = selectionPhone == null ? null : selectionPhone.trim();
    }

    public String getRecommendTime() {
        return recommendTime;
    }

    public void setRecommendTime(String recommendTime) {
        this.recommendTime = recommendTime == null ? null : recommendTime.trim();
    }

    public String getSupplierCondition() {
        return supplierCondition;
    }

    public void setSupplierCondition(String supplierCondition) {
        this.supplierCondition = supplierCondition == null ? null : supplierCondition.trim();
    }

    public String getSampleCondition() {
        return sampleCondition;
    }

    public void setSampleCondition(String sampleCondition) {
        this.sampleCondition = sampleCondition == null ? null : sampleCondition.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress == null ? null : companyAddress.trim();
    }

    public String getPersonName() {
        return personName;
    }

    public void setPersonName(String personName) {
        this.personName = personName == null ? null : personName.trim();
    }

    public String getCompanyContacts() {
        return companyContacts;
    }

    public void setCompanyContacts(String companyContacts) {
        this.companyContacts = companyContacts == null ? null : companyContacts.trim();
    }

    public String getContactsTelephone() {
        return contactsTelephone;
    }

    public void setContactsTelephone(String contactsTelephone) {
        this.contactsTelephone = contactsTelephone == null ? null : contactsTelephone.trim();
    }

    public String getContactsPhone() {
        return contactsPhone;
    }

    public void setContactsPhone(String contactsPhone) {
        this.contactsPhone = contactsPhone == null ? null : contactsPhone.trim();
    }

    public String getRegisteredCapital() {
        return registeredCapital;
    }

    public void setRegisteredCapital(String registeredCapital) {
        this.registeredCapital = registeredCapital == null ? null : registeredCapital.trim();
    }

    public String getEstablishTime() {
        return establishTime;
    }

    public void setEstablishTime(String establishTime) {
        this.establishTime = establishTime == null ? null : establishTime.trim();
    }

    public String getBusinessContacts() {
        return businessContacts;
    }

    public void setBusinessContacts(String businessContacts) {
        this.businessContacts = businessContacts == null ? null : businessContacts.trim();
    }

    public String getContactsEmail() {
        return contactsEmail;
    }

    public void setContactsEmail(String contactsEmail) {
        this.contactsEmail = contactsEmail == null ? null : contactsEmail.trim();
    }

    public String getBankInformation() {
        return bankInformation;
    }

    public void setBankInformation(String bankInformation) {
        this.bankInformation = bankInformation == null ? null : bankInformation.trim();
    }

    public String getCompanyAccount() {
        return companyAccount;
    }

    public void setCompanyAccount(String companyAccount) {
        this.companyAccount = companyAccount == null ? null : companyAccount.trim();
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber == null ? null : taxNumber.trim();
    }

    public String getPeopleCapacity() {
        return peopleCapacity;
    }

    public void setPeopleCapacity(String peopleCapacity) {
        this.peopleCapacity = peopleCapacity == null ? null : peopleCapacity.trim();
    }

    public String getBusinessScope() {
        return businessScope;
    }

    public void setBusinessScope(String businessScope) {
        this.businessScope = businessScope == null ? null : businessScope.trim();
    }

    public String getLicenseImageurl() {
        return licenseImageurl;
    }

    public void setLicenseImageurl(String licenseImageurl) {
        this.licenseImageurl = licenseImageurl == null ? null : licenseImageurl.trim();
    }

    public String getOrganizationImageurl() {
        return organizationImageurl;
    }

    public void setOrganizationImageurl(String organizationImageurl) {
        this.organizationImageurl = organizationImageurl == null ? null : organizationImageurl.trim();
    }

    public String getRegisterImageurl() {
        return registerImageurl;
    }

    public void setRegisterImageurl(String registerImageurl) {
        this.registerImageurl = registerImageurl == null ? null : registerImageurl.trim();
    }

    public String getReportImageurl() {
        return reportImageurl;
    }

    public void setReportImageurl(String reportImageurl) {
        this.reportImageurl = reportImageurl == null ? null : reportImageurl.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public String getProductCategory() {
        return productCategory;
    }

    public void setProductCategory(String productCategory) {
        this.productCategory = productCategory == null ? null : productCategory.trim();
    }

    public String getProductBurden() {
        return productBurden;
    }

    public void setProductBurden(String productBurden) {
        this.productBurden = productBurden == null ? null : productBurden.trim();
    }

    public String getContentPabulum() {
        return contentPabulum;
    }

    public void setContentPabulum(String contentPabulum) {
        this.contentPabulum = contentPabulum == null ? null : contentPabulum.trim();
    }

    public String getStockpileWayandtime() {
        return stockpileWayandtime;
    }

    public void setStockpileWayandtime(String stockpileWayandtime) {
        this.stockpileWayandtime = stockpileWayandtime == null ? null : stockpileWayandtime.trim();
    }

    public String getProductNumber() {
        return productNumber;
    }

    public void setProductNumber(String productNumber) {
        this.productNumber = productNumber == null ? null : productNumber.trim();
    }

    public String getPermitNumber() {
        return permitNumber;
    }

    public void setPermitNumber(String permitNumber) {
        this.permitNumber = permitNumber == null ? null : permitNumber.trim();
    }

    public String getProductSpecialty() {
        return productSpecialty;
    }

    public void setProductSpecialty(String productSpecialty) {
        this.productSpecialty = productSpecialty == null ? null : productSpecialty.trim();
    }

    public String getProductRemark() {
        return productRemark;
    }

    public void setProductRemark(String productRemark) {
        this.productRemark = productRemark == null ? null : productRemark.trim();
    }

    public String getProductUrl() {
        return productUrl;
    }

    public void setProductUrl(String productUrl) {
        this.productUrl = productUrl == null ? null : productUrl.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }
}
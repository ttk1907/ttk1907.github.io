package com.zng.mapper;

import com.zng.model.TAuthentication;

public interface TAuthenticationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TAuthentication record);

    int insertSelective(TAuthentication record);

    TAuthentication selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TAuthentication record);

    int updateByPrimaryKey(TAuthentication record);
}
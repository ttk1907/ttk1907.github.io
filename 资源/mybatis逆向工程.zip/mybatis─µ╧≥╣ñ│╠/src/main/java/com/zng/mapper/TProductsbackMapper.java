package com.zng.mapper;

import com.zng.model.TProductsback;

public interface TProductsbackMapper {
    int deleteByPrimaryKey(String id);

    int insert(TProductsback record);

    int insertSelective(TProductsback record);

    TProductsback selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TProductsback record);

    int updateByPrimaryKey(TProductsback record);
}
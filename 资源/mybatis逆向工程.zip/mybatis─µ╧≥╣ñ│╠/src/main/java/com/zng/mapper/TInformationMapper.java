package com.zng.mapper;

import com.zng.model.TInformation;

public interface TInformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TInformation record);

    int insertSelective(TInformation record);

    TInformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TInformation record);

    int updateByPrimaryKey(TInformation record);
}
package com.zng.mapper;

import com.zng.model.TDouyindata;

public interface TDouyindataMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDouyindata record);

    int insertSelective(TDouyindata record);

    TDouyindata selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDouyindata record);

    int updateByPrimaryKey(TDouyindata record);
}
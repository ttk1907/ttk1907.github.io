package com.zng.model;

import java.io.Serializable;

public class TTeamoney implements Serializable {
    private String id;

    private String phone;

    private Long money;

    private String loginId;

    private Long oneTengNum;

    private Long oneBaiNum;

    private Long twoTengNum;

    private Long twoBaiNum;

    private String createTime;

    private String updateTime;

    private String state;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Long getMoney() {
        return money;
    }

    public void setMoney(Long money) {
        this.money = money;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public Long getOneTengNum() {
        return oneTengNum;
    }

    public void setOneTengNum(Long oneTengNum) {
        this.oneTengNum = oneTengNum;
    }

    public Long getOneBaiNum() {
        return oneBaiNum;
    }

    public void setOneBaiNum(Long oneBaiNum) {
        this.oneBaiNum = oneBaiNum;
    }

    public Long getTwoTengNum() {
        return twoTengNum;
    }

    public void setTwoTengNum(Long twoTengNum) {
        this.twoTengNum = twoTengNum;
    }

    public Long getTwoBaiNum() {
        return twoBaiNum;
    }

    public void setTwoBaiNum(Long twoBaiNum) {
        this.twoBaiNum = twoBaiNum;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TClassteaminformation;

public interface TClassteaminformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TClassteaminformation record);

    int insertSelective(TClassteaminformation record);

    TClassteaminformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TClassteaminformation record);

    int updateByPrimaryKey(TClassteaminformation record);
}
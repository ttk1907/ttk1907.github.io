package com.zng.mapper;

import com.zng.model.TTeaminformation;

public interface TTeaminformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTeaminformation record);

    int insertSelective(TTeaminformation record);

    TTeaminformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTeaminformation record);

    int updateByPrimaryKey(TTeaminformation record);
}
package com.zng.model;

import java.io.Serializable;

public class TRelationship implements Serializable {
    private Integer id;

    private String regimentId;

    private String togetherId;

    private String regimentName;

    private String authenticationId;

    private String createTime;

    private String state;

    private String businessId;

    private String place;

    private String placeId;

    private String wechatId;

    private static final long serialVersionUID = 1L;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getRegimentId() {
        return regimentId;
    }

    public void setRegimentId(String regimentId) {
        this.regimentId = regimentId == null ? null : regimentId.trim();
    }

    public String getTogetherId() {
        return togetherId;
    }

    public void setTogetherId(String togetherId) {
        this.togetherId = togetherId == null ? null : togetherId.trim();
    }

    public String getRegimentName() {
        return regimentName;
    }

    public void setRegimentName(String regimentName) {
        this.regimentName = regimentName == null ? null : regimentName.trim();
    }

    public String getAuthenticationId() {
        return authenticationId;
    }

    public void setAuthenticationId(String authenticationId) {
        this.authenticationId = authenticationId == null ? null : authenticationId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getBusinessId() {
        return businessId;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId == null ? null : businessId.trim();
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place == null ? null : place.trim();
    }

    public String getPlaceId() {
        return placeId;
    }

    public void setPlaceId(String placeId) {
        this.placeId = placeId == null ? null : placeId.trim();
    }

    public String getWechatId() {
        return wechatId;
    }

    public void setWechatId(String wechatId) {
        this.wechatId = wechatId == null ? null : wechatId.trim();
    }
}
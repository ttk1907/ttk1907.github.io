package com.zng.mapper;

import com.zng.model.TLive;

public interface TLiveMapper {
    int deleteByPrimaryKey(String id);

    int insert(TLive record);

    int insertSelective(TLive record);

    TLive selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TLive record);

    int updateByPrimaryKey(TLive record);
}
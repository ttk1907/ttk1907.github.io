package com.zng.mapper;

import com.zng.model.TClassteaminto;

public interface TClassteamintoMapper {
    int deleteByPrimaryKey(String id);

    int insert(TClassteaminto record);

    int insertSelective(TClassteaminto record);

    TClassteaminto selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TClassteaminto record);

    int updateByPrimaryKey(TClassteaminto record);
}
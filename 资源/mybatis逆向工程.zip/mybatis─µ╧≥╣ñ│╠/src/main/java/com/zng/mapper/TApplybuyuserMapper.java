package com.zng.mapper;

import com.zng.model.TApplybuyuser;

public interface TApplybuyuserMapper {
    int deleteByPrimaryKey(String id);

    int insert(TApplybuyuser record);

    int insertSelective(TApplybuyuser record);

    TApplybuyuser selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TApplybuyuser record);

    int updateByPrimaryKey(TApplybuyuser record);
}
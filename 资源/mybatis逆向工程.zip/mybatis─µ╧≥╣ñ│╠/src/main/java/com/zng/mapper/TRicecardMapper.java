package com.zng.mapper;

import com.zng.model.TRicecard;

public interface TRicecardMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRicecard record);

    int insertSelective(TRicecard record);

    TRicecard selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRicecard record);

    int updateByPrimaryKey(TRicecard record);
}
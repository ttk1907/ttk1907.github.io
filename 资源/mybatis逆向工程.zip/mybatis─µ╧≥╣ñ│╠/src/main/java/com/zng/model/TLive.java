package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TLive implements Serializable {
    private String id;

    private String loginId;

    private String roomId;

    private String state;

    private String createTime;

    private String updateTime;

    private String name;

    private Long startTime;

    private Long endTime;

    private String anchorName;

    private String anchorWechat;

    private String subAnchorWechat;

    private Integer isFeedsPublic;

    private Integer type;

    private Integer screenType;

    private Integer closeLike;

    private Integer closeGoods;

    private Integer closeComment;

    private Integer closeReplay;

    private Integer closeShare;

    private Integer closeKf;

    private String liveCommodityid;

    private String mediaId;

    private String coverImg;

    private String shareImg;

    private String feedsImg;

    private String shareCode;

    private String teamLeaderPhone;

    private String teamLeaderLoginId;

    private String pushStreamCode;

    private String liveType;

    private String coverUrl;

    private String medicalAccount;

    private String anchorAccount;

    private String discountType;

    private BigDecimal firstDiscount;

    private BigDecimal secondDiscount;

    private Integer commodityNum;

    private String liveTemplateId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getRoomId() {
        return roomId;
    }

    public void setRoomId(String roomId) {
        this.roomId = roomId == null ? null : roomId.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Long getStartTime() {
        return startTime;
    }

    public void setStartTime(Long startTime) {
        this.startTime = startTime;
    }

    public Long getEndTime() {
        return endTime;
    }

    public void setEndTime(Long endTime) {
        this.endTime = endTime;
    }

    public String getAnchorName() {
        return anchorName;
    }

    public void setAnchorName(String anchorName) {
        this.anchorName = anchorName == null ? null : anchorName.trim();
    }

    public String getAnchorWechat() {
        return anchorWechat;
    }

    public void setAnchorWechat(String anchorWechat) {
        this.anchorWechat = anchorWechat == null ? null : anchorWechat.trim();
    }

    public String getSubAnchorWechat() {
        return subAnchorWechat;
    }

    public void setSubAnchorWechat(String subAnchorWechat) {
        this.subAnchorWechat = subAnchorWechat == null ? null : subAnchorWechat.trim();
    }

    public Integer getIsFeedsPublic() {
        return isFeedsPublic;
    }

    public void setIsFeedsPublic(Integer isFeedsPublic) {
        this.isFeedsPublic = isFeedsPublic;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getScreenType() {
        return screenType;
    }

    public void setScreenType(Integer screenType) {
        this.screenType = screenType;
    }

    public Integer getCloseLike() {
        return closeLike;
    }

    public void setCloseLike(Integer closeLike) {
        this.closeLike = closeLike;
    }

    public Integer getCloseGoods() {
        return closeGoods;
    }

    public void setCloseGoods(Integer closeGoods) {
        this.closeGoods = closeGoods;
    }

    public Integer getCloseComment() {
        return closeComment;
    }

    public void setCloseComment(Integer closeComment) {
        this.closeComment = closeComment;
    }

    public Integer getCloseReplay() {
        return closeReplay;
    }

    public void setCloseReplay(Integer closeReplay) {
        this.closeReplay = closeReplay;
    }

    public Integer getCloseShare() {
        return closeShare;
    }

    public void setCloseShare(Integer closeShare) {
        this.closeShare = closeShare;
    }

    public Integer getCloseKf() {
        return closeKf;
    }

    public void setCloseKf(Integer closeKf) {
        this.closeKf = closeKf;
    }

    public String getLiveCommodityid() {
        return liveCommodityid;
    }

    public void setLiveCommodityid(String liveCommodityid) {
        this.liveCommodityid = liveCommodityid == null ? null : liveCommodityid.trim();
    }

    public String getMediaId() {
        return mediaId;
    }

    public void setMediaId(String mediaId) {
        this.mediaId = mediaId == null ? null : mediaId.trim();
    }

    public String getCoverImg() {
        return coverImg;
    }

    public void setCoverImg(String coverImg) {
        this.coverImg = coverImg == null ? null : coverImg.trim();
    }

    public String getShareImg() {
        return shareImg;
    }

    public void setShareImg(String shareImg) {
        this.shareImg = shareImg == null ? null : shareImg.trim();
    }

    public String getFeedsImg() {
        return feedsImg;
    }

    public void setFeedsImg(String feedsImg) {
        this.feedsImg = feedsImg == null ? null : feedsImg.trim();
    }

    public String getShareCode() {
        return shareCode;
    }

    public void setShareCode(String shareCode) {
        this.shareCode = shareCode == null ? null : shareCode.trim();
    }

    public String getTeamLeaderPhone() {
        return teamLeaderPhone;
    }

    public void setTeamLeaderPhone(String teamLeaderPhone) {
        this.teamLeaderPhone = teamLeaderPhone == null ? null : teamLeaderPhone.trim();
    }

    public String getTeamLeaderLoginId() {
        return teamLeaderLoginId;
    }

    public void setTeamLeaderLoginId(String teamLeaderLoginId) {
        this.teamLeaderLoginId = teamLeaderLoginId == null ? null : teamLeaderLoginId.trim();
    }

    public String getPushStreamCode() {
        return pushStreamCode;
    }

    public void setPushStreamCode(String pushStreamCode) {
        this.pushStreamCode = pushStreamCode == null ? null : pushStreamCode.trim();
    }

    public String getLiveType() {
        return liveType;
    }

    public void setLiveType(String liveType) {
        this.liveType = liveType == null ? null : liveType.trim();
    }

    public String getCoverUrl() {
        return coverUrl;
    }

    public void setCoverUrl(String coverUrl) {
        this.coverUrl = coverUrl == null ? null : coverUrl.trim();
    }

    public String getMedicalAccount() {
        return medicalAccount;
    }

    public void setMedicalAccount(String medicalAccount) {
        this.medicalAccount = medicalAccount == null ? null : medicalAccount.trim();
    }

    public String getAnchorAccount() {
        return anchorAccount;
    }

    public void setAnchorAccount(String anchorAccount) {
        this.anchorAccount = anchorAccount == null ? null : anchorAccount.trim();
    }

    public String getDiscountType() {
        return discountType;
    }

    public void setDiscountType(String discountType) {
        this.discountType = discountType == null ? null : discountType.trim();
    }

    public BigDecimal getFirstDiscount() {
        return firstDiscount;
    }

    public void setFirstDiscount(BigDecimal firstDiscount) {
        this.firstDiscount = firstDiscount;
    }

    public BigDecimal getSecondDiscount() {
        return secondDiscount;
    }

    public void setSecondDiscount(BigDecimal secondDiscount) {
        this.secondDiscount = secondDiscount;
    }

    public Integer getCommodityNum() {
        return commodityNum;
    }

    public void setCommodityNum(Integer commodityNum) {
        this.commodityNum = commodityNum;
    }

    public String getLiveTemplateId() {
        return liveTemplateId;
    }

    public void setLiveTemplateId(String liveTemplateId) {
        this.liveTemplateId = liveTemplateId == null ? null : liveTemplateId.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TFinancialstatement;

public interface TFinancialstatementMapper {
    int deleteByPrimaryKey(String id);

    int insert(TFinancialstatement record);

    int insertSelective(TFinancialstatement record);

    TFinancialstatement selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TFinancialstatement record);

    int updateByPrimaryKey(TFinancialstatement record);
}
package com.zng.mapper;

import com.zng.model.TBaiyilock;

public interface TBaiyilockMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBaiyilock record);

    int insertSelective(TBaiyilock record);

    TBaiyilock selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBaiyilock record);

    int updateByPrimaryKey(TBaiyilock record);
}
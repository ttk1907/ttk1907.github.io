package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TApplyanchor implements Serializable {
    private String id;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String anchorWechat;

    private String type;

    private String liverLoginid;

    private String adminPhone;

    private String rejectionTime;

    private BigDecimal previousPerformance;

    private BigDecimal periodPerformance;

    private BigDecimal totalPerformance;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getAnchorWechat() {
        return anchorWechat;
    }

    public void setAnchorWechat(String anchorWechat) {
        this.anchorWechat = anchorWechat == null ? null : anchorWechat.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getLiverLoginid() {
        return liverLoginid;
    }

    public void setLiverLoginid(String liverLoginid) {
        this.liverLoginid = liverLoginid == null ? null : liverLoginid.trim();
    }

    public String getAdminPhone() {
        return adminPhone;
    }

    public void setAdminPhone(String adminPhone) {
        this.adminPhone = adminPhone == null ? null : adminPhone.trim();
    }

    public String getRejectionTime() {
        return rejectionTime;
    }

    public void setRejectionTime(String rejectionTime) {
        this.rejectionTime = rejectionTime == null ? null : rejectionTime.trim();
    }

    public BigDecimal getPreviousPerformance() {
        return previousPerformance;
    }

    public void setPreviousPerformance(BigDecimal previousPerformance) {
        this.previousPerformance = previousPerformance;
    }

    public BigDecimal getPeriodPerformance() {
        return periodPerformance;
    }

    public void setPeriodPerformance(BigDecimal periodPerformance) {
        this.periodPerformance = periodPerformance;
    }

    public BigDecimal getTotalPerformance() {
        return totalPerformance;
    }

    public void setTotalPerformance(BigDecimal totalPerformance) {
        this.totalPerformance = totalPerformance;
    }
}
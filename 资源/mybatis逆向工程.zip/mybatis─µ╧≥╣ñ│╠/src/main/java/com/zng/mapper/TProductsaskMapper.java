package com.zng.mapper;

import com.zng.model.TProductsask;

public interface TProductsaskMapper {
    int deleteByPrimaryKey(String id);

    int insert(TProductsask record);

    int insertSelective(TProductsask record);

    TProductsask selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TProductsask record);

    int updateByPrimaryKey(TProductsask record);
}
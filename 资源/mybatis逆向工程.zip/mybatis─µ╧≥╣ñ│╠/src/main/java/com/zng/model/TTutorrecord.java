package com.zng.model;

import java.io.Serializable;

public class TTutorrecord implements Serializable {
    private String id;

    private String loginId;

    private Integer tutorFailedNum;

    private Integer tutorSuccessNum;

    private String isDowngrade;

    private String cancelDate;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public Integer getTutorFailedNum() {
        return tutorFailedNum;
    }

    public void setTutorFailedNum(Integer tutorFailedNum) {
        this.tutorFailedNum = tutorFailedNum;
    }

    public Integer getTutorSuccessNum() {
        return tutorSuccessNum;
    }

    public void setTutorSuccessNum(Integer tutorSuccessNum) {
        this.tutorSuccessNum = tutorSuccessNum;
    }

    public String getIsDowngrade() {
        return isDowngrade;
    }

    public void setIsDowngrade(String isDowngrade) {
        this.isDowngrade = isDowngrade == null ? null : isDowngrade.trim();
    }

    public String getCancelDate() {
        return cancelDate;
    }

    public void setCancelDate(String cancelDate) {
        this.cancelDate = cancelDate == null ? null : cancelDate.trim();
    }
}
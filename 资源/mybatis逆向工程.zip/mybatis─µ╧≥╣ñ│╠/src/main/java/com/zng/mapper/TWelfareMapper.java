package com.zng.mapper;

import com.zng.model.TWelfare;

public interface TWelfareMapper {
    int deleteByPrimaryKey(String id);

    int insert(TWelfare record);

    int insertSelective(TWelfare record);

    TWelfare selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TWelfare record);

    int updateByPrimaryKey(TWelfare record);
}
package com.zng.mapper;

import com.zng.model.TGrowtype;

public interface TGrowtypeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGrowtype record);

    int insertSelective(TGrowtype record);

    TGrowtype selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGrowtype record);

    int updateByPrimaryKey(TGrowtype record);
}
package com.zng.mapper;

import com.zng.model.TDailytask;

public interface TDailytaskMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDailytask record);

    int insertSelective(TDailytask record);

    TDailytask selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDailytask record);

    int updateByPrimaryKey(TDailytask record);
}
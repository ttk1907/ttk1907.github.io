package com.zng.mapper;

import com.zng.model.TLikerecord;

public interface TLikerecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(TLikerecord record);

    int insertSelective(TLikerecord record);

    TLikerecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TLikerecord record);

    int updateByPrimaryKey(TLikerecord record);
}
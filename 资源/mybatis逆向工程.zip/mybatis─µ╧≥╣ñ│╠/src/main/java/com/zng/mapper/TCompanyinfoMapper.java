package com.zng.mapper;

import com.zng.model.TCompanyinfo;

public interface TCompanyinfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCompanyinfo record);

    int insertSelective(TCompanyinfo record);

    TCompanyinfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCompanyinfo record);

    int updateByPrimaryKey(TCompanyinfo record);
}
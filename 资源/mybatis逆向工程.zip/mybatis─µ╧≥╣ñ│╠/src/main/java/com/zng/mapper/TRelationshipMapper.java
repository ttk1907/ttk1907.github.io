package com.zng.mapper;

import com.zng.model.TRelationship;

public interface TRelationshipMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TRelationship record);

    int insertSelective(TRelationship record);

    TRelationship selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TRelationship record);

    int updateByPrimaryKey(TRelationship record);
}
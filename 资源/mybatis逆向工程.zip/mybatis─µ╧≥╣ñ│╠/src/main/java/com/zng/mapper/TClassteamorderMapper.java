package com.zng.mapper;

import com.zng.model.TClassteamorder;

public interface TClassteamorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TClassteamorder record);

    int insertSelective(TClassteamorder record);

    TClassteamorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TClassteamorder record);

    int updateByPrimaryKey(TClassteamorder record);
}
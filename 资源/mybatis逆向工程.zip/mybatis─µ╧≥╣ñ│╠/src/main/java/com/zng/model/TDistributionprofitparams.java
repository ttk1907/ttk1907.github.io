package com.zng.model;

import java.io.Serializable;

public class TDistributionprofitparams implements Serializable {
    private String id;

    private String averagePrice;

    private String togetherWelfare;

    private String togetherWelfareTwo;

    private String togetherBuyOneself;

    private String togetherBuyFirst;

    private String togetherBuyTwo;

    private String excellenceBuyOneself;

    private String excellenceBuyFirst;

    private String excellenceBuyTwo;

    private String headToken;

    private String groupBuyCash;

    private String classCommitteeFate;

    private String tutorFate;

    private String repeatBuyOne;

    private String repeatBuyTwo;

    private String repeatBuyThree;

    private String authTogetherFate;

    private String state;

    private String createTime;

    private String updateTime;

    private String scoreRatio;

    private String youXuanRate;

    private String huiXuanRate;

    private String teamReward;

    private String gameReward;

    private String operation;

    private String production;

    private String platform;

    private String technology;

    private String reward;

    private String gong;

    private String hou;

    private String bo;

    private String zi;

    private String nan;

    private String tokenReduceMultiple;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getAveragePrice() {
        return averagePrice;
    }

    public void setAveragePrice(String averagePrice) {
        this.averagePrice = averagePrice == null ? null : averagePrice.trim();
    }

    public String getTogetherWelfare() {
        return togetherWelfare;
    }

    public void setTogetherWelfare(String togetherWelfare) {
        this.togetherWelfare = togetherWelfare == null ? null : togetherWelfare.trim();
    }

    public String getTogetherWelfareTwo() {
        return togetherWelfareTwo;
    }

    public void setTogetherWelfareTwo(String togetherWelfareTwo) {
        this.togetherWelfareTwo = togetherWelfareTwo == null ? null : togetherWelfareTwo.trim();
    }

    public String getTogetherBuyOneself() {
        return togetherBuyOneself;
    }

    public void setTogetherBuyOneself(String togetherBuyOneself) {
        this.togetherBuyOneself = togetherBuyOneself == null ? null : togetherBuyOneself.trim();
    }

    public String getTogetherBuyFirst() {
        return togetherBuyFirst;
    }

    public void setTogetherBuyFirst(String togetherBuyFirst) {
        this.togetherBuyFirst = togetherBuyFirst == null ? null : togetherBuyFirst.trim();
    }

    public String getTogetherBuyTwo() {
        return togetherBuyTwo;
    }

    public void setTogetherBuyTwo(String togetherBuyTwo) {
        this.togetherBuyTwo = togetherBuyTwo == null ? null : togetherBuyTwo.trim();
    }

    public String getExcellenceBuyOneself() {
        return excellenceBuyOneself;
    }

    public void setExcellenceBuyOneself(String excellenceBuyOneself) {
        this.excellenceBuyOneself = excellenceBuyOneself == null ? null : excellenceBuyOneself.trim();
    }

    public String getExcellenceBuyFirst() {
        return excellenceBuyFirst;
    }

    public void setExcellenceBuyFirst(String excellenceBuyFirst) {
        this.excellenceBuyFirst = excellenceBuyFirst == null ? null : excellenceBuyFirst.trim();
    }

    public String getExcellenceBuyTwo() {
        return excellenceBuyTwo;
    }

    public void setExcellenceBuyTwo(String excellenceBuyTwo) {
        this.excellenceBuyTwo = excellenceBuyTwo == null ? null : excellenceBuyTwo.trim();
    }

    public String getHeadToken() {
        return headToken;
    }

    public void setHeadToken(String headToken) {
        this.headToken = headToken == null ? null : headToken.trim();
    }

    public String getGroupBuyCash() {
        return groupBuyCash;
    }

    public void setGroupBuyCash(String groupBuyCash) {
        this.groupBuyCash = groupBuyCash == null ? null : groupBuyCash.trim();
    }

    public String getClassCommitteeFate() {
        return classCommitteeFate;
    }

    public void setClassCommitteeFate(String classCommitteeFate) {
        this.classCommitteeFate = classCommitteeFate == null ? null : classCommitteeFate.trim();
    }

    public String getTutorFate() {
        return tutorFate;
    }

    public void setTutorFate(String tutorFate) {
        this.tutorFate = tutorFate == null ? null : tutorFate.trim();
    }

    public String getRepeatBuyOne() {
        return repeatBuyOne;
    }

    public void setRepeatBuyOne(String repeatBuyOne) {
        this.repeatBuyOne = repeatBuyOne == null ? null : repeatBuyOne.trim();
    }

    public String getRepeatBuyTwo() {
        return repeatBuyTwo;
    }

    public void setRepeatBuyTwo(String repeatBuyTwo) {
        this.repeatBuyTwo = repeatBuyTwo == null ? null : repeatBuyTwo.trim();
    }

    public String getRepeatBuyThree() {
        return repeatBuyThree;
    }

    public void setRepeatBuyThree(String repeatBuyThree) {
        this.repeatBuyThree = repeatBuyThree == null ? null : repeatBuyThree.trim();
    }

    public String getAuthTogetherFate() {
        return authTogetherFate;
    }

    public void setAuthTogetherFate(String authTogetherFate) {
        this.authTogetherFate = authTogetherFate == null ? null : authTogetherFate.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getScoreRatio() {
        return scoreRatio;
    }

    public void setScoreRatio(String scoreRatio) {
        this.scoreRatio = scoreRatio == null ? null : scoreRatio.trim();
    }

    public String getYouXuanRate() {
        return youXuanRate;
    }

    public void setYouXuanRate(String youXuanRate) {
        this.youXuanRate = youXuanRate == null ? null : youXuanRate.trim();
    }

    public String getHuiXuanRate() {
        return huiXuanRate;
    }

    public void setHuiXuanRate(String huiXuanRate) {
        this.huiXuanRate = huiXuanRate == null ? null : huiXuanRate.trim();
    }

    public String getTeamReward() {
        return teamReward;
    }

    public void setTeamReward(String teamReward) {
        this.teamReward = teamReward == null ? null : teamReward.trim();
    }

    public String getGameReward() {
        return gameReward;
    }

    public void setGameReward(String gameReward) {
        this.gameReward = gameReward == null ? null : gameReward.trim();
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation == null ? null : operation.trim();
    }

    public String getProduction() {
        return production;
    }

    public void setProduction(String production) {
        this.production = production == null ? null : production.trim();
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform == null ? null : platform.trim();
    }

    public String getTechnology() {
        return technology;
    }

    public void setTechnology(String technology) {
        this.technology = technology == null ? null : technology.trim();
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward == null ? null : reward.trim();
    }

    public String getGong() {
        return gong;
    }

    public void setGong(String gong) {
        this.gong = gong == null ? null : gong.trim();
    }

    public String getHou() {
        return hou;
    }

    public void setHou(String hou) {
        this.hou = hou == null ? null : hou.trim();
    }

    public String getBo() {
        return bo;
    }

    public void setBo(String bo) {
        this.bo = bo == null ? null : bo.trim();
    }

    public String getZi() {
        return zi;
    }

    public void setZi(String zi) {
        this.zi = zi == null ? null : zi.trim();
    }

    public String getNan() {
        return nan;
    }

    public void setNan(String nan) {
        this.nan = nan == null ? null : nan.trim();
    }

    public String getTokenReduceMultiple() {
        return tokenReduceMultiple;
    }

    public void setTokenReduceMultiple(String tokenReduceMultiple) {
        this.tokenReduceMultiple = tokenReduceMultiple == null ? null : tokenReduceMultiple.trim();
    }
}
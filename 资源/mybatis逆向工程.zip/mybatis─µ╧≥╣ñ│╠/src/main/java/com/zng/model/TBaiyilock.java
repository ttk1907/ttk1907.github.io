package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TBaiyilock implements Serializable {
    private String id;

    private String loginId;

    private BigDecimal token;

    private BigDecimal price;

    private String phone;

    private String name;

    private String state;

    private String createTime;

    private String updateTime;

    private Integer num;

    private String startTime;

    private String endTime;

    private BigDecimal freeToken;

    private Integer promoteTwoRank;

    private Integer promoteThreeRank;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public BigDecimal getToken() {
        return token;
    }

    public void setToken(BigDecimal token) {
        this.token = token;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime == null ? null : startTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public BigDecimal getFreeToken() {
        return freeToken;
    }

    public void setFreeToken(BigDecimal freeToken) {
        this.freeToken = freeToken;
    }

    public Integer getPromoteTwoRank() {
        return promoteTwoRank;
    }

    public void setPromoteTwoRank(Integer promoteTwoRank) {
        this.promoteTwoRank = promoteTwoRank;
    }

    public Integer getPromoteThreeRank() {
        return promoteThreeRank;
    }

    public void setPromoteThreeRank(Integer promoteThreeRank) {
        this.promoteThreeRank = promoteThreeRank;
    }
}
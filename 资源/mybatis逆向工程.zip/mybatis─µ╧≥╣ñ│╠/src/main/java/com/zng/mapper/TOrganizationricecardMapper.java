package com.zng.mapper;

import com.zng.model.TOrganizationricecard;

public interface TOrganizationricecardMapper {
    int deleteByPrimaryKey(String id);

    int insert(TOrganizationricecard record);

    int insertSelective(TOrganizationricecard record);

    TOrganizationricecard selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TOrganizationricecard record);

    int updateByPrimaryKey(TOrganizationricecard record);
}
package com.zng.mapper;

import com.zng.model.TTransfer;

public interface TTransferMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTransfer record);

    int insertSelective(TTransfer record);

    TTransfer selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTransfer record);

    int updateByPrimaryKey(TTransfer record);
}
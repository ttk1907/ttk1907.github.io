package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TCashout implements Serializable {
    private String id;

    private String loginId;

    private String companyName;

    private String bank;

    private String createTime;

    private String endTime;

    private String cashOutState;

    private BigDecimal cash;

    private String areaState;

    private String accountNumber;

    private String serialNumber;

    private String proofUrl;

    private String disposeArea;

    private String transferState;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getBank() {
        return bank;
    }

    public void setBank(String bank) {
        this.bank = bank == null ? null : bank.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public String getCashOutState() {
        return cashOutState;
    }

    public void setCashOutState(String cashOutState) {
        this.cashOutState = cashOutState == null ? null : cashOutState.trim();
    }

    public BigDecimal getCash() {
        return cash;
    }

    public void setCash(BigDecimal cash) {
        this.cash = cash;
    }

    public String getAreaState() {
        return areaState;
    }

    public void setAreaState(String areaState) {
        this.areaState = areaState == null ? null : areaState.trim();
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber == null ? null : accountNumber.trim();
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber == null ? null : serialNumber.trim();
    }

    public String getProofUrl() {
        return proofUrl;
    }

    public void setProofUrl(String proofUrl) {
        this.proofUrl = proofUrl == null ? null : proofUrl.trim();
    }

    public String getDisposeArea() {
        return disposeArea;
    }

    public void setDisposeArea(String disposeArea) {
        this.disposeArea = disposeArea == null ? null : disposeArea.trim();
    }

    public String getTransferState() {
        return transferState;
    }

    public void setTransferState(String transferState) {
        this.transferState = transferState == null ? null : transferState.trim();
    }
}
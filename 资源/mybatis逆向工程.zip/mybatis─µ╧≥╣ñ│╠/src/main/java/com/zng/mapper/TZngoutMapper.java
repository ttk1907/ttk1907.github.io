package com.zng.mapper;

import com.zng.model.TZngout;

public interface TZngoutMapper {
    int deleteByPrimaryKey(String id);

    int insert(TZngout record);

    int insertSelective(TZngout record);

    TZngout selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TZngout record);

    int updateByPrimaryKey(TZngout record);
}
package com.zng.mapper;

import com.zng.model.TGrowcomment;

public interface TGrowcommentMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGrowcomment record);

    int insertSelective(TGrowcomment record);

    TGrowcomment selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGrowcomment record);

    int updateByPrimaryKey(TGrowcomment record);
}
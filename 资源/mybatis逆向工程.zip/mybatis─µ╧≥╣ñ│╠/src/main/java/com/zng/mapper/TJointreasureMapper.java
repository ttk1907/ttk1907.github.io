package com.zng.mapper;

import com.zng.model.TJointreasure;

public interface TJointreasureMapper {
    int deleteByPrimaryKey(String id);

    int insert(TJointreasure record);

    int insertSelective(TJointreasure record);

    TJointreasure selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TJointreasure record);

    int updateByPrimaryKey(TJointreasure record);
}
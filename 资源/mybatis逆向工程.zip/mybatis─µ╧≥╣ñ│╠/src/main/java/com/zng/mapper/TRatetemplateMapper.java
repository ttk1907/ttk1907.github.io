package com.zng.mapper;

import com.zng.model.TRatetemplate;

public interface TRatetemplateMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRatetemplate record);

    int insertSelective(TRatetemplate record);

    TRatetemplate selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRatetemplate record);

    int updateByPrimaryKey(TRatetemplate record);
}
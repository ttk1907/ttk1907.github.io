package com.zng.mapper;

import com.zng.model.TDiseasecategory;

public interface TDiseasecategoryMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDiseasecategory record);

    int insertSelective(TDiseasecategory record);

    TDiseasecategory selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDiseasecategory record);

    int updateByPrimaryKey(TDiseasecategory record);
}
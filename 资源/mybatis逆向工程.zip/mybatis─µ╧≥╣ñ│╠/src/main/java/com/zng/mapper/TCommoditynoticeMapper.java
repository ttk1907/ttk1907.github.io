package com.zng.mapper;

import com.zng.model.TCommoditynotice;

public interface TCommoditynoticeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommoditynotice record);

    int insertSelective(TCommoditynotice record);

    TCommoditynotice selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommoditynotice record);

    int updateByPrimaryKey(TCommoditynotice record);
}
package com.zng.mapper;

import com.zng.model.TCompanyorder;

public interface TCompanyorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCompanyorder record);

    int insertSelective(TCompanyorder record);

    TCompanyorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCompanyorder record);

    int updateByPrimaryKey(TCompanyorder record);
}
package com.zng.mrdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MrdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MrdemoApplication.class, args);
    }

}

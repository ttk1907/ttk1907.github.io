package com.zng.mapper;

import com.zng.model.TTogethercommoditytwo;

public interface TTogethercommoditytwoMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogethercommoditytwo record);

    int insertSelective(TTogethercommoditytwo record);

    TTogethercommoditytwo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogethercommoditytwo record);

    int updateByPrimaryKey(TTogethercommoditytwo record);
}
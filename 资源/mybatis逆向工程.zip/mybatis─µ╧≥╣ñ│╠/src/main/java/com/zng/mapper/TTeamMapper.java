package com.zng.mapper;

import com.zng.model.TTeam;

public interface TTeamMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTeam record);

    int insertSelective(TTeam record);

    TTeam selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTeam record);

    int updateByPrimaryKey(TTeam record);
}
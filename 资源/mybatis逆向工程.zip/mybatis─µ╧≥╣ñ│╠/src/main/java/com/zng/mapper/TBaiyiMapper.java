package com.zng.mapper;

import com.zng.model.TBaiyi;

public interface TBaiyiMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBaiyi record);

    int insertSelective(TBaiyi record);

    TBaiyi selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBaiyi record);

    int updateByPrimaryKey(TBaiyi record);
}
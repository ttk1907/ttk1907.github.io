package com.zng.model;

import java.io.Serializable;

public class TArea implements Serializable {
    private String id;

    private String name;

    private String pid;

    private String createTime;

    private String updateTime;

    private Integer grade;

    private String state;

    private Integer isMunicipality;

    private Integer isTogetherSpace;

    private String areaState;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid == null ? null : pid.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public Integer getIsMunicipality() {
        return isMunicipality;
    }

    public void setIsMunicipality(Integer isMunicipality) {
        this.isMunicipality = isMunicipality;
    }

    public Integer getIsTogetherSpace() {
        return isTogetherSpace;
    }

    public void setIsTogetherSpace(Integer isTogetherSpace) {
        this.isTogetherSpace = isTogetherSpace;
    }

    public String getAreaState() {
        return areaState;
    }

    public void setAreaState(String areaState) {
        this.areaState = areaState == null ? null : areaState.trim();
    }
}
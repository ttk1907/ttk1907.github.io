package com.zng.mapper;

import com.zng.model.TType;

public interface TTypeMapper {
    int deleteByPrimaryKey(String id);

    int insert(TType record);

    int insertSelective(TType record);

    TType selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TType record);

    int updateByPrimaryKey(TType record);
}
package com.zng.mapper;

import com.zng.model.TOrganization;

public interface TOrganizationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TOrganization record);

    int insertSelective(TOrganization record);

    TOrganization selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TOrganization record);

    int updateByPrimaryKey(TOrganization record);
}
package com.zng.mapper;

import com.zng.model.TAssignmentCopy;

public interface TAssignmentCopyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TAssignmentCopy record);

    int insertSelective(TAssignmentCopy record);

    TAssignmentCopy selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TAssignmentCopy record);

    int updateByPrimaryKey(TAssignmentCopy record);
}
package com.zng.mapper;

import com.zng.model.TProductsapplication;

public interface TProductsapplicationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TProductsapplication record);

    int insertSelective(TProductsapplication record);

    TProductsapplication selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TProductsapplication record);

    int updateByPrimaryKey(TProductsapplication record);
}
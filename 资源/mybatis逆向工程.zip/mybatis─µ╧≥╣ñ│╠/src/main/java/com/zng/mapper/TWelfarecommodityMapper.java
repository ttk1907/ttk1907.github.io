package com.zng.mapper;

import com.zng.model.TWelfarecommodity;

public interface TWelfarecommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TWelfarecommodity record);

    int insertSelective(TWelfarecommodity record);

    TWelfarecommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TWelfarecommodity record);

    int updateByPrimaryKey(TWelfarecommodity record);
}
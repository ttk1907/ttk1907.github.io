package com.zng.mapper;

import com.zng.model.TDouyin;

public interface TDouyinMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDouyin record);

    int insertSelective(TDouyin record);

    TDouyin selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDouyin record);

    int updateByPrimaryKey(TDouyin record);
}
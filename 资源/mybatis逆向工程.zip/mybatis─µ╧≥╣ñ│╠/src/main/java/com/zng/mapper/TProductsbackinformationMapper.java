package com.zng.mapper;

import com.zng.model.TProductsbackinformation;

public interface TProductsbackinformationMapper {
    int deleteByPrimaryKey(String id);

    int insert(TProductsbackinformation record);

    int insertSelective(TProductsbackinformation record);

    TProductsbackinformation selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TProductsbackinformation record);

    int updateByPrimaryKey(TProductsbackinformation record);
}
package com.zng.mapper;

import com.zng.model.TSecurity;

public interface TSecurityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TSecurity record);

    int insertSelective(TSecurity record);

    TSecurity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TSecurity record);

    int updateByPrimaryKey(TSecurity record);
}
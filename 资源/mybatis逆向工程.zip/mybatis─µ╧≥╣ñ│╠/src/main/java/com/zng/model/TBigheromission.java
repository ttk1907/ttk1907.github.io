package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TBigheromission implements Serializable {
    private String id;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String courseOneState;

    private String courseTwoState;

    private String courseThreeState;

    private String challengeOneState;

    private String courseFourState;

    private BigDecimal reward;

    private String isJoinLive;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCourseOneState() {
        return courseOneState;
    }

    public void setCourseOneState(String courseOneState) {
        this.courseOneState = courseOneState == null ? null : courseOneState.trim();
    }

    public String getCourseTwoState() {
        return courseTwoState;
    }

    public void setCourseTwoState(String courseTwoState) {
        this.courseTwoState = courseTwoState == null ? null : courseTwoState.trim();
    }

    public String getCourseThreeState() {
        return courseThreeState;
    }

    public void setCourseThreeState(String courseThreeState) {
        this.courseThreeState = courseThreeState == null ? null : courseThreeState.trim();
    }

    public String getChallengeOneState() {
        return challengeOneState;
    }

    public void setChallengeOneState(String challengeOneState) {
        this.challengeOneState = challengeOneState == null ? null : challengeOneState.trim();
    }

    public String getCourseFourState() {
        return courseFourState;
    }

    public void setCourseFourState(String courseFourState) {
        this.courseFourState = courseFourState == null ? null : courseFourState.trim();
    }

    public BigDecimal getReward() {
        return reward;
    }

    public void setReward(BigDecimal reward) {
        this.reward = reward;
    }

    public String getIsJoinLive() {
        return isJoinLive;
    }

    public void setIsJoinLive(String isJoinLive) {
        this.isJoinLive = isJoinLive == null ? null : isJoinLive.trim();
    }
}
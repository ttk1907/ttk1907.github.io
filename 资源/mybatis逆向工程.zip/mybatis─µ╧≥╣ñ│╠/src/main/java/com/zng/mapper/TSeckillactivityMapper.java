package com.zng.mapper;

import com.zng.model.TSeckillactivity;

public interface TSeckillactivityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TSeckillactivity record);

    int insertSelective(TSeckillactivity record);

    TSeckillactivity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TSeckillactivity record);

    int updateByPrimaryKey(TSeckillactivity record);
}
package com.zng.mapper;

import com.zng.model.TActivitydraw;

public interface TActivitydrawMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivitydraw record);

    int insertSelective(TActivitydraw record);

    TActivitydraw selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivitydraw record);

    int updateByPrimaryKey(TActivitydraw record);
}
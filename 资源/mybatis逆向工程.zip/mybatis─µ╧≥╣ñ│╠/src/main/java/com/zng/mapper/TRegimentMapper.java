package com.zng.mapper;

import com.zng.model.TRegiment;

public interface TRegimentMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRegiment record);

    int insertSelective(TRegiment record);

    TRegiment selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRegiment record);

    int updateByPrimaryKey(TRegiment record);
}
package com.zng.model;

import java.io.Serializable;

public class TSports implements Serializable {
    private String id;

    private String zng;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String bondLoginId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getZng() {
        return zng;
    }

    public void setZng(String zng) {
        this.zng = zng == null ? null : zng.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getBondLoginId() {
        return bondLoginId;
    }

    public void setBondLoginId(String bondLoginId) {
        this.bondLoginId = bondLoginId == null ? null : bondLoginId.trim();
    }
}
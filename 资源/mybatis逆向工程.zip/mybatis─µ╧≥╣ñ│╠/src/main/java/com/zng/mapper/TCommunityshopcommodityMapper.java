package com.zng.mapper;

import com.zng.model.TCommunityshopcommodity;

public interface TCommunityshopcommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommunityshopcommodity record);

    int insertSelective(TCommunityshopcommodity record);

    TCommunityshopcommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommunityshopcommodity record);

    int updateByPrimaryKey(TCommunityshopcommodity record);
}
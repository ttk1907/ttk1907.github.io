package com.zng.mapper;

import com.zng.model.TCommunityshopactivityinto;

public interface TCommunityshopactivityintoMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommunityshopactivityinto record);

    int insertSelective(TCommunityshopactivityinto record);

    TCommunityshopactivityinto selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommunityshopactivityinto record);

    int updateByPrimaryKey(TCommunityshopactivityinto record);
}
package com.zng.mapper;

import com.zng.model.TReview;

public interface TReviewMapper {
    int deleteByPrimaryKey(String id);

    int insert(TReview record);

    int insertSelective(TReview record);

    TReview selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TReview record);

    int updateByPrimaryKeyWithBLOBs(TReview record);

    int updateByPrimaryKey(TReview record);
}
package com.zng.mapper;

import com.zng.model.TActivityinto;

public interface TActivityintoMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivityinto record);

    int insertSelective(TActivityinto record);

    TActivityinto selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivityinto record);

    int updateByPrimaryKey(TActivityinto record);
}
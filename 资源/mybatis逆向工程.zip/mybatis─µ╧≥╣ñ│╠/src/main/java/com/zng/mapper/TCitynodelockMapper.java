package com.zng.mapper;

import com.zng.model.TCitynodelock;

public interface TCitynodelockMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCitynodelock record);

    int insertSelective(TCitynodelock record);

    TCitynodelock selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCitynodelock record);

    int updateByPrimaryKey(TCitynodelock record);
}
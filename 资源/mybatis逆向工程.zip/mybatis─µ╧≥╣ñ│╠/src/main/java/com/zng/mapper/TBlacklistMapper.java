package com.zng.mapper;

import com.zng.model.TBlacklist;

public interface TBlacklistMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBlacklist record);

    int insertSelective(TBlacklist record);

    TBlacklist selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBlacklist record);

    int updateByPrimaryKey(TBlacklist record);
}
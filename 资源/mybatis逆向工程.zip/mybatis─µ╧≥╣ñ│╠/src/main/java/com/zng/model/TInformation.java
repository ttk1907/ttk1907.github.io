package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TInformation implements Serializable {
    private String id;

    private String nickName;

    private String idNumber;

    private String evaluate;

    private String parentsId;

    private String goodAt;

    private String credit;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private String grandParentsId;

    private String roleId;

    private String type;

    private String invitationCode;

    private String portraitUrl;

    private Double totalSum;

    private String sum;

    private String sex;

    private String birthday;

    private String details;

    private String consultant;

    private String isClassCommittee;

    private String cancelClassCommitteeTime;

    private Integer activationNum;

    private BigDecimal performance;

    private String bigHeroState;

    private Integer failedNum;

    private String isModifyParent;

    private String togetherBuyState;

    private String monthBuyState;

    private Integer modifyNum;

    private Integer isModifyNum;

    private String customizationBuyState;

    private String bindTime;

    private String isBaiYi;

    private String isPromoteThree;

    private String isCommunity;

    private String isPledge;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName == null ? null : nickName.trim();
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber == null ? null : idNumber.trim();
    }

    public String getEvaluate() {
        return evaluate;
    }

    public void setEvaluate(String evaluate) {
        this.evaluate = evaluate == null ? null : evaluate.trim();
    }

    public String getParentsId() {
        return parentsId;
    }

    public void setParentsId(String parentsId) {
        this.parentsId = parentsId == null ? null : parentsId.trim();
    }

    public String getGoodAt() {
        return goodAt;
    }

    public void setGoodAt(String goodAt) {
        this.goodAt = goodAt == null ? null : goodAt.trim();
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit == null ? null : credit.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getGrandParentsId() {
        return grandParentsId;
    }

    public void setGrandParentsId(String grandParentsId) {
        this.grandParentsId = grandParentsId == null ? null : grandParentsId.trim();
    }

    public String getRoleId() {
        return roleId;
    }

    public void setRoleId(String roleId) {
        this.roleId = roleId == null ? null : roleId.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getInvitationCode() {
        return invitationCode;
    }

    public void setInvitationCode(String invitationCode) {
        this.invitationCode = invitationCode == null ? null : invitationCode.trim();
    }

    public String getPortraitUrl() {
        return portraitUrl;
    }

    public void setPortraitUrl(String portraitUrl) {
        this.portraitUrl = portraitUrl == null ? null : portraitUrl.trim();
    }

    public Double getTotalSum() {
        return totalSum;
    }

    public void setTotalSum(Double totalSum) {
        this.totalSum = totalSum;
    }

    public String getSum() {
        return sum;
    }

    public void setSum(String sum) {
        this.sum = sum == null ? null : sum.trim();
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex == null ? null : sex.trim();
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday == null ? null : birthday.trim();
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details == null ? null : details.trim();
    }

    public String getConsultant() {
        return consultant;
    }

    public void setConsultant(String consultant) {
        this.consultant = consultant == null ? null : consultant.trim();
    }

    public String getIsClassCommittee() {
        return isClassCommittee;
    }

    public void setIsClassCommittee(String isClassCommittee) {
        this.isClassCommittee = isClassCommittee == null ? null : isClassCommittee.trim();
    }

    public String getCancelClassCommitteeTime() {
        return cancelClassCommitteeTime;
    }

    public void setCancelClassCommitteeTime(String cancelClassCommitteeTime) {
        this.cancelClassCommitteeTime = cancelClassCommitteeTime == null ? null : cancelClassCommitteeTime.trim();
    }

    public Integer getActivationNum() {
        return activationNum;
    }

    public void setActivationNum(Integer activationNum) {
        this.activationNum = activationNum;
    }

    public BigDecimal getPerformance() {
        return performance;
    }

    public void setPerformance(BigDecimal performance) {
        this.performance = performance;
    }

    public String getBigHeroState() {
        return bigHeroState;
    }

    public void setBigHeroState(String bigHeroState) {
        this.bigHeroState = bigHeroState == null ? null : bigHeroState.trim();
    }

    public Integer getFailedNum() {
        return failedNum;
    }

    public void setFailedNum(Integer failedNum) {
        this.failedNum = failedNum;
    }

    public String getIsModifyParent() {
        return isModifyParent;
    }

    public void setIsModifyParent(String isModifyParent) {
        this.isModifyParent = isModifyParent == null ? null : isModifyParent.trim();
    }

    public String getTogetherBuyState() {
        return togetherBuyState;
    }

    public void setTogetherBuyState(String togetherBuyState) {
        this.togetherBuyState = togetherBuyState == null ? null : togetherBuyState.trim();
    }

    public String getMonthBuyState() {
        return monthBuyState;
    }

    public void setMonthBuyState(String monthBuyState) {
        this.monthBuyState = monthBuyState == null ? null : monthBuyState.trim();
    }

    public Integer getModifyNum() {
        return modifyNum;
    }

    public void setModifyNum(Integer modifyNum) {
        this.modifyNum = modifyNum;
    }

    public Integer getIsModifyNum() {
        return isModifyNum;
    }

    public void setIsModifyNum(Integer isModifyNum) {
        this.isModifyNum = isModifyNum;
    }

    public String getCustomizationBuyState() {
        return customizationBuyState;
    }

    public void setCustomizationBuyState(String customizationBuyState) {
        this.customizationBuyState = customizationBuyState == null ? null : customizationBuyState.trim();
    }

    public String getBindTime() {
        return bindTime;
    }

    public void setBindTime(String bindTime) {
        this.bindTime = bindTime == null ? null : bindTime.trim();
    }

    public String getIsBaiYi() {
        return isBaiYi;
    }

    public void setIsBaiYi(String isBaiYi) {
        this.isBaiYi = isBaiYi == null ? null : isBaiYi.trim();
    }

    public String getIsPromoteThree() {
        return isPromoteThree;
    }

    public void setIsPromoteThree(String isPromoteThree) {
        this.isPromoteThree = isPromoteThree == null ? null : isPromoteThree.trim();
    }

    public String getIsCommunity() {
        return isCommunity;
    }

    public void setIsCommunity(String isCommunity) {
        this.isCommunity = isCommunity == null ? null : isCommunity.trim();
    }

    public String getIsPledge() {
        return isPledge;
    }

    public void setIsPledge(String isPledge) {
        this.isPledge = isPledge == null ? null : isPledge.trim();
    }
}
package com.zng.model;

import java.io.Serializable;

public class TFadada implements Serializable {
    private String id;

    private String loginId;

    private String createTime;

    private String updateTime;

    private String state;

    private String customerId;

    private String transactionNo;

    private String contractId1;

    private String contractId2;

    private String contractId3;

    private String contractId4;

    private String batchId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId == null ? null : customerId.trim();
    }

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo == null ? null : transactionNo.trim();
    }

    public String getContractId1() {
        return contractId1;
    }

    public void setContractId1(String contractId1) {
        this.contractId1 = contractId1 == null ? null : contractId1.trim();
    }

    public String getContractId2() {
        return contractId2;
    }

    public void setContractId2(String contractId2) {
        this.contractId2 = contractId2 == null ? null : contractId2.trim();
    }

    public String getContractId3() {
        return contractId3;
    }

    public void setContractId3(String contractId3) {
        this.contractId3 = contractId3 == null ? null : contractId3.trim();
    }

    public String getContractId4() {
        return contractId4;
    }

    public void setContractId4(String contractId4) {
        this.contractId4 = contractId4 == null ? null : contractId4.trim();
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId == null ? null : batchId.trim();
    }
}
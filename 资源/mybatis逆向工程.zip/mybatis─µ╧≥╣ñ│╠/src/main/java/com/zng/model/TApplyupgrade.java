package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TApplyupgrade implements Serializable {
    private String id;

    private String loginId;

    private String createTime;

    private String updateTime;

    private String state;

    private String type;

    private String imgUrl;

    private String phone;

    private String rejectionTime;

    private String tutorLoginId;

    private BigDecimal previousPerformance;

    private BigDecimal periodPerformance;

    private BigDecimal totalPerformance;

    private Integer courseNum;

    private Integer activeNum;

    private BigDecimal previousScore;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl == null ? null : imgUrl.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getRejectionTime() {
        return rejectionTime;
    }

    public void setRejectionTime(String rejectionTime) {
        this.rejectionTime = rejectionTime == null ? null : rejectionTime.trim();
    }

    public String getTutorLoginId() {
        return tutorLoginId;
    }

    public void setTutorLoginId(String tutorLoginId) {
        this.tutorLoginId = tutorLoginId == null ? null : tutorLoginId.trim();
    }

    public BigDecimal getPreviousPerformance() {
        return previousPerformance;
    }

    public void setPreviousPerformance(BigDecimal previousPerformance) {
        this.previousPerformance = previousPerformance;
    }

    public BigDecimal getPeriodPerformance() {
        return periodPerformance;
    }

    public void setPeriodPerformance(BigDecimal periodPerformance) {
        this.periodPerformance = periodPerformance;
    }

    public BigDecimal getTotalPerformance() {
        return totalPerformance;
    }

    public void setTotalPerformance(BigDecimal totalPerformance) {
        this.totalPerformance = totalPerformance;
    }

    public Integer getCourseNum() {
        return courseNum;
    }

    public void setCourseNum(Integer courseNum) {
        this.courseNum = courseNum;
    }

    public Integer getActiveNum() {
        return activeNum;
    }

    public void setActiveNum(Integer activeNum) {
        this.activeNum = activeNum;
    }

    public BigDecimal getPreviousScore() {
        return previousScore;
    }

    public void setPreviousScore(BigDecimal previousScore) {
        this.previousScore = previousScore;
    }
}
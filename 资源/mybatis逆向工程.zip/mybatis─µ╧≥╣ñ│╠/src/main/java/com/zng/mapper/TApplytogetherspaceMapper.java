package com.zng.mapper;

import com.zng.model.TApplytogetherspace;

public interface TApplytogetherspaceMapper {
    int deleteByPrimaryKey(String id);

    int insert(TApplytogetherspace record);

    int insertSelective(TApplytogetherspace record);

    TApplytogetherspace selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TApplytogetherspace record);

    int updateByPrimaryKey(TApplytogetherspace record);
}
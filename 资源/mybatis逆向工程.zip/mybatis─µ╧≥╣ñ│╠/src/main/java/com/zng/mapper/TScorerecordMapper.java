package com.zng.mapper;

import com.zng.model.TScorerecord;

public interface TScorerecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(TScorerecord record);

    int insertSelective(TScorerecord record);

    TScorerecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TScorerecord record);

    int updateByPrimaryKey(TScorerecord record);
}
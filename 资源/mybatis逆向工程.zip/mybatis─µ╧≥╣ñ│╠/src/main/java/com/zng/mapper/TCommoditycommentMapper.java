package com.zng.mapper;

import com.zng.model.TCommoditycomment;

public interface TCommoditycommentMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommoditycomment record);

    int insertSelective(TCommoditycomment record);

    TCommoditycomment selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommoditycomment record);

    int updateByPrimaryKey(TCommoditycomment record);
}
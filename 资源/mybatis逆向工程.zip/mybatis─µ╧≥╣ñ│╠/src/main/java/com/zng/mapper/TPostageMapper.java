package com.zng.mapper;

import com.zng.model.TPostage;

public interface TPostageMapper {
    int deleteByPrimaryKey(String id);

    int insert(TPostage record);

    int insertSelective(TPostage record);

    TPostage selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TPostage record);

    int updateByPrimaryKey(TPostage record);
}
package com.zng.mapper;

import com.zng.model.TLogin;
import com.zng.model.TLoginExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TLoginMapper {
    long countByExample(TLoginExample example);

    int deleteByExample(TLoginExample example);

    int deleteByPrimaryKey(String id);

    int insert(TLogin record);

    int insertSelective(TLogin record);

    List<TLogin> selectByExample(TLoginExample example);

    TLogin selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") TLogin record, @Param("example") TLoginExample example);

    int updateByExample(@Param("record") TLogin record, @Param("example") TLoginExample example);

    int updateByPrimaryKeySelective(TLogin record);

    int updateByPrimaryKey(TLogin record);
}
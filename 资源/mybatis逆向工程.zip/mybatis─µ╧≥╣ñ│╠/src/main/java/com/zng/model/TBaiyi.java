package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TBaiyi implements Serializable {
    private String id;

    private String loginId;

    private BigDecimal money;

    private String phone;

    private Integer num;

    private String state;

    private String createTime;

    private String updateTime;

    private String receivePaymentImg;

    private String reviewState;

    private String reviewImg;

    private String bankNum;

    private String accountName;

    private String bankAddress;

    private String name;

    private String idcupUrl;

    private String idcdownUrl;

    private String endReviewState;

    private BigDecimal price;

    private String idcNumber;

    private String inviterPhone;

    private String cityName;

    private String cityId;

    private String provinceId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public BigDecimal getMoney() {
        return money;
    }

    public void setMoney(BigDecimal money) {
        this.money = money;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public Integer getNum() {
        return num;
    }

    public void setNum(Integer num) {
        this.num = num;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getReceivePaymentImg() {
        return receivePaymentImg;
    }

    public void setReceivePaymentImg(String receivePaymentImg) {
        this.receivePaymentImg = receivePaymentImg == null ? null : receivePaymentImg.trim();
    }

    public String getReviewState() {
        return reviewState;
    }

    public void setReviewState(String reviewState) {
        this.reviewState = reviewState == null ? null : reviewState.trim();
    }

    public String getReviewImg() {
        return reviewImg;
    }

    public void setReviewImg(String reviewImg) {
        this.reviewImg = reviewImg == null ? null : reviewImg.trim();
    }

    public String getBankNum() {
        return bankNum;
    }

    public void setBankNum(String bankNum) {
        this.bankNum = bankNum == null ? null : bankNum.trim();
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName == null ? null : accountName.trim();
    }

    public String getBankAddress() {
        return bankAddress;
    }

    public void setBankAddress(String bankAddress) {
        this.bankAddress = bankAddress == null ? null : bankAddress.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getIdcupUrl() {
        return idcupUrl;
    }

    public void setIdcupUrl(String idcupUrl) {
        this.idcupUrl = idcupUrl == null ? null : idcupUrl.trim();
    }

    public String getIdcdownUrl() {
        return idcdownUrl;
    }

    public void setIdcdownUrl(String idcdownUrl) {
        this.idcdownUrl = idcdownUrl == null ? null : idcdownUrl.trim();
    }

    public String getEndReviewState() {
        return endReviewState;
    }

    public void setEndReviewState(String endReviewState) {
        this.endReviewState = endReviewState == null ? null : endReviewState.trim();
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public String getIdcNumber() {
        return idcNumber;
    }

    public void setIdcNumber(String idcNumber) {
        this.idcNumber = idcNumber == null ? null : idcNumber.trim();
    }

    public String getInviterPhone() {
        return inviterPhone;
    }

    public void setInviterPhone(String inviterPhone) {
        this.inviterPhone = inviterPhone == null ? null : inviterPhone.trim();
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName == null ? null : cityName.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId == null ? null : provinceId.trim();
    }
}
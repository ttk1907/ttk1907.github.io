package com.zng.mapper;

import com.zng.model.TIncomedisburse;

public interface TIncomedisburseMapper {
    int deleteByPrimaryKey(String id);

    int insert(TIncomedisburse record);

    int insertSelective(TIncomedisburse record);

    TIncomedisburse selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TIncomedisburse record);

    int updateByPrimaryKey(TIncomedisburse record);
}
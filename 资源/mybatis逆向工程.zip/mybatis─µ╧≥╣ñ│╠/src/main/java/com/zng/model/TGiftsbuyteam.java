package com.zng.model;

import java.io.Serializable;

public class TGiftsbuyteam implements Serializable {
    private String id;

    private String loginId;

    private String inviterLogin;

    private String state;

    private String createTime;

    private String updateTime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getInviterLogin() {
        return inviterLogin;
    }

    public void setInviterLogin(String inviterLogin) {
        this.inviterLogin = inviterLogin == null ? null : inviterLogin.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }
}
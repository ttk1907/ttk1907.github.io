package com.zng.mapper;

import com.zng.model.TLivetemplate;

public interface TLivetemplateMapper {
    int deleteByPrimaryKey(String id);

    int insert(TLivetemplate record);

    int insertSelective(TLivetemplate record);

    TLivetemplate selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TLivetemplate record);

    int updateByPrimaryKey(TLivetemplate record);
}
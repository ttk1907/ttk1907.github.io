package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class TChangetoken implements Serializable {
    private String id;

    private String changeType;

    private BigDecimal changeNumber;

    private String state;

    private String createTime;

    private String updateTime;

    private BigDecimal originNumber;

    private String fromloginId;

    private String tologinId;

    private Date changeTime;

    private Integer period;

    private Integer changtime;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getChangeType() {
        return changeType;
    }

    public void setChangeType(String changeType) {
        this.changeType = changeType == null ? null : changeType.trim();
    }

    public BigDecimal getChangeNumber() {
        return changeNumber;
    }

    public void setChangeNumber(BigDecimal changeNumber) {
        this.changeNumber = changeNumber;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public BigDecimal getOriginNumber() {
        return originNumber;
    }

    public void setOriginNumber(BigDecimal originNumber) {
        this.originNumber = originNumber;
    }

    public String getFromloginId() {
        return fromloginId;
    }

    public void setFromloginId(String fromloginId) {
        this.fromloginId = fromloginId == null ? null : fromloginId.trim();
    }

    public String getTologinId() {
        return tologinId;
    }

    public void setTologinId(String tologinId) {
        this.tologinId = tologinId == null ? null : tologinId.trim();
    }

    public Date getChangeTime() {
        return changeTime;
    }

    public void setChangeTime(Date changeTime) {
        this.changeTime = changeTime;
    }

    public Integer getPeriod() {
        return period;
    }

    public void setPeriod(Integer period) {
        this.period = period;
    }

    public Integer getChangtime() {
        return changtime;
    }

    public void setChangtime(Integer changtime) {
        this.changtime = changtime;
    }
}
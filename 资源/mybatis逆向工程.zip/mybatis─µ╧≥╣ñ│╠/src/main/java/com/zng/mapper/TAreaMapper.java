package com.zng.mapper;

import com.zng.model.TArea;

public interface TAreaMapper {
    int deleteByPrimaryKey(String id);

    int insert(TArea record);

    int insertSelective(TArea record);

    TArea selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TArea record);

    int updateByPrimaryKey(TArea record);
}
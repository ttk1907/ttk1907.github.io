package com.zng.mapper;

import com.zng.model.TRetails;

public interface TRetailsMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRetails record);

    int insertSelective(TRetails record);

    TRetails selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRetails record);

    int updateByPrimaryKey(TRetails record);
}
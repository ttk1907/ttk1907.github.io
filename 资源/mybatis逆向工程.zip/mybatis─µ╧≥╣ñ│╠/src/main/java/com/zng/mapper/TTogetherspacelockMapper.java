package com.zng.mapper;

import com.zng.model.TTogetherspacelock;

public interface TTogetherspacelockMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogetherspacelock record);

    int insertSelective(TTogetherspacelock record);

    TTogetherspacelock selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogetherspacelock record);

    int updateByPrimaryKey(TTogetherspacelock record);
}
package com.zng.mapper;

import com.zng.model.TLock;

public interface TLockMapper {
    int deleteByPrimaryKey(String id);

    int insert(TLock record);

    int insertSelective(TLock record);

    TLock selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TLock record);

    int updateByPrimaryKey(TLock record);
}
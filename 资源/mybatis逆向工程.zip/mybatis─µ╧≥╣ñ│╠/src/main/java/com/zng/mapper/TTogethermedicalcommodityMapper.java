package com.zng.mapper;

import com.zng.model.TTogethermedicalcommodity;

public interface TTogethermedicalcommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogethermedicalcommodity record);

    int insertSelective(TTogethermedicalcommodity record);

    TTogethermedicalcommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogethermedicalcommodity record);

    int updateByPrimaryKey(TTogethermedicalcommodity record);
}
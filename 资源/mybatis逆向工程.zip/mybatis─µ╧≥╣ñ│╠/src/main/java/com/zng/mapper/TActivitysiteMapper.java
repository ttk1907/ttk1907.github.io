package com.zng.mapper;

import com.zng.model.TActivitysite;

public interface TActivitysiteMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivitysite record);

    int insertSelective(TActivitysite record);

    TActivitysite selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivitysite record);

    int updateByPrimaryKey(TActivitysite record);
}
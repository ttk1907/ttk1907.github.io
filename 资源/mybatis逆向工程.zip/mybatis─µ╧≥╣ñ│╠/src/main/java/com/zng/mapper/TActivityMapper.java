package com.zng.mapper;

import com.zng.model.TActivity;

public interface TActivityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TActivity record);

    int insertSelective(TActivity record);

    TActivity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TActivity record);

    int updateByPrimaryKey(TActivity record);
}
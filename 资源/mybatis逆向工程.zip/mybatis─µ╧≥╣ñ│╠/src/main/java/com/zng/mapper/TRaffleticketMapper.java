package com.zng.mapper;

import com.zng.model.TRaffleticket;

public interface TRaffleticketMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRaffleticket record);

    int insertSelective(TRaffleticket record);

    TRaffleticket selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRaffleticket record);

    int updateByPrimaryKey(TRaffleticket record);
}
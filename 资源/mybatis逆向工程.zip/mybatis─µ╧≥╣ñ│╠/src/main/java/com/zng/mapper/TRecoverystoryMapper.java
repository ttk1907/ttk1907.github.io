package com.zng.mapper;

import com.zng.model.TRecoverystory;

public interface TRecoverystoryMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRecoverystory record);

    int insertSelective(TRecoverystory record);

    TRecoverystory selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRecoverystory record);

    int updateByPrimaryKey(TRecoverystory record);
}
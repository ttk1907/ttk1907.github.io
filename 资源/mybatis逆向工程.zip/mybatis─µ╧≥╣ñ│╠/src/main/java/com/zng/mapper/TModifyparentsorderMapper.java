package com.zng.mapper;

import com.zng.model.TModifyparentsorder;

public interface TModifyparentsorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TModifyparentsorder record);

    int insertSelective(TModifyparentsorder record);

    TModifyparentsorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TModifyparentsorder record);

    int updateByPrimaryKey(TModifyparentsorder record);
}
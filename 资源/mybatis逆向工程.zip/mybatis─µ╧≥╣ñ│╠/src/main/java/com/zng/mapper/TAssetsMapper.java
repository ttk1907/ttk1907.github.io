package com.zng.mapper;

import com.zng.model.TAssets;

public interface TAssetsMapper {
    int deleteByPrimaryKey(String id);

    int insert(TAssets record);

    int insertSelective(TAssets record);

    TAssets selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TAssets record);

    int updateByPrimaryKey(TAssets record);
}
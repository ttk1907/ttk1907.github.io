package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TAssets implements Serializable {
    private String id;

    private BigDecimal token;

    private String state;

    private String createTime;

    private String updateTime;

    private String loginId;

    private Integer tengzunTea;

    private Integer baiyuTea;

    private BigDecimal quota;

    private Integer newTeaNum;

    private BigDecimal redemptionAmount;

    private String isExchange;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getToken() {
        return token;
    }

    public void setToken(BigDecimal token) {
        this.token = token;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public Integer getTengzunTea() {
        return tengzunTea;
    }

    public void setTengzunTea(Integer tengzunTea) {
        this.tengzunTea = tengzunTea;
    }

    public Integer getBaiyuTea() {
        return baiyuTea;
    }

    public void setBaiyuTea(Integer baiyuTea) {
        this.baiyuTea = baiyuTea;
    }

    public BigDecimal getQuota() {
        return quota;
    }

    public void setQuota(BigDecimal quota) {
        this.quota = quota;
    }

    public Integer getNewTeaNum() {
        return newTeaNum;
    }

    public void setNewTeaNum(Integer newTeaNum) {
        this.newTeaNum = newTeaNum;
    }

    public BigDecimal getRedemptionAmount() {
        return redemptionAmount;
    }

    public void setRedemptionAmount(BigDecimal redemptionAmount) {
        this.redemptionAmount = redemptionAmount;
    }

    public String getIsExchange() {
        return isExchange;
    }

    public void setIsExchange(String isExchange) {
        this.isExchange = isExchange == null ? null : isExchange.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TInvoice;

public interface TInvoiceMapper {
    int deleteByPrimaryKey(String id);

    int insert(TInvoice record);

    int insertSelective(TInvoice record);

    TInvoice selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TInvoice record);

    int updateByPrimaryKey(TInvoice record);
}
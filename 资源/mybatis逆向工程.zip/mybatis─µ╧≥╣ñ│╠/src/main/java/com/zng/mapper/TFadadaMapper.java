package com.zng.mapper;

import com.zng.model.TFadada;

public interface TFadadaMapper {
    int deleteByPrimaryKey(String id);

    int insert(TFadada record);

    int insertSelective(TFadada record);

    TFadada selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TFadada record);

    int updateByPrimaryKey(TFadada record);
}
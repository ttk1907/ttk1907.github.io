package com.zng.mapper;

import com.zng.model.TCommunityshopmedicalcommodity;

public interface TCommunityshopmedicalcommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommunityshopmedicalcommodity record);

    int insertSelective(TCommunityshopmedicalcommodity record);

    TCommunityshopmedicalcommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommunityshopmedicalcommodity record);

    int updateByPrimaryKey(TCommunityshopmedicalcommodity record);
}
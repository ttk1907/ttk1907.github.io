package com.zng.model;

import java.io.Serializable;

public class TRatetemplate implements Serializable {
    private String id;

    private String operation;

    private String firstCash;

    private String firstToken;

    private String secondCash;

    private String secondToken;

    private String city;

    private String score;

    private String platform;

    private String produce;

    private String system;

    private String supplement;

    private String zngCompany;

    private String remaining;

    private String remarks;

    private String state;

    private String createTime;

    private String updateTime;

    private String type;

    private String togetherSpace;

    private String conversionTea;

    private String tokenRelease;

    private String buyOneself;

    private String drawReserved;

    private String adminAccount;

    private String businessId;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation == null ? null : operation.trim();
    }

    public String getFirstCash() {
        return firstCash;
    }

    public void setFirstCash(String firstCash) {
        this.firstCash = firstCash == null ? null : firstCash.trim();
    }

    public String getFirstToken() {
        return firstToken;
    }

    public void setFirstToken(String firstToken) {
        this.firstToken = firstToken == null ? null : firstToken.trim();
    }

    public String getSecondCash() {
        return secondCash;
    }

    public void setSecondCash(String secondCash) {
        this.secondCash = secondCash == null ? null : secondCash.trim();
    }

    public String getSecondToken() {
        return secondToken;
    }

    public void setSecondToken(String secondToken) {
        this.secondToken = secondToken == null ? null : secondToken.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score == null ? null : score.trim();
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform == null ? null : platform.trim();
    }

    public String getProduce() {
        return produce;
    }

    public void setProduce(String produce) {
        this.produce = produce == null ? null : produce.trim();
    }

    public String getSystem() {
        return system;
    }

    public void setSystem(String system) {
        this.system = system == null ? null : system.trim();
    }

    public String getSupplement() {
        return supplement;
    }

    public void setSupplement(String supplement) {
        this.supplement = supplement == null ? null : supplement.trim();
    }

    public String getZngCompany() {
        return zngCompany;
    }

    public void setZngCompany(String zngCompany) {
        this.zngCompany = zngCompany == null ? null : zngCompany.trim();
    }

    public String getRemaining() {
        return remaining;
    }

    public void setRemaining(String remaining) {
        this.remaining = remaining == null ? null : remaining.trim();
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getTogetherSpace() {
        return togetherSpace;
    }

    public void setTogetherSpace(String togetherSpace) {
        this.togetherSpace = togetherSpace == null ? null : togetherSpace.trim();
    }

    public String getConversionTea() {
        return conversionTea;
    }

    public void setConversionTea(String conversionTea) {
        this.conversionTea = conversionTea == null ? null : conversionTea.trim();
    }

    public String getTokenRelease() {
        return tokenRelease;
    }

    public void setTokenRelease(String tokenRelease) {
        this.tokenRelease = tokenRelease == null ? null : tokenRelease.trim();
    }

    public String getBuyOneself() {
        return buyOneself;
    }

    public void setBuyOneself(String buyOneself) {
        this.buyOneself = buyOneself == null ? null : buyOneself.trim();
    }

    public String getDrawReserved() {
        return drawReserved;
    }

    public void setDrawReserved(String drawReserved) {
        this.drawReserved = drawReserved == null ? null : drawReserved.trim();
    }

    public String getAdminAccount() {
        return adminAccount;
    }

    public void setAdminAccount(String adminAccount) {
        this.adminAccount = adminAccount == null ? null : adminAccount.trim();
    }

    public String getBusinessId() {
        return businessId;
    }

    public void setBusinessId(String businessId) {
        this.businessId = businessId == null ? null : businessId.trim();
    }
}
package com.zng.mapper;

import com.zng.model.TTearedeem;

public interface TTearedeemMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTearedeem record);

    int insertSelective(TTearedeem record);

    TTearedeem selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTearedeem record);

    int updateByPrimaryKey(TTearedeem record);
}
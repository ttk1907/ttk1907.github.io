package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TScore implements Serializable {
    private String id;

    private BigDecimal interpersonalFraction;

    private BigDecimal abilityFraction;

    private BigDecimal sincerityFraction;

    private BigDecimal deedFraction;

    private BigDecimal experienceFraction;

    private String raterLoginId;

    private String state;

    private String createTime;

    private String updateTime;

    private String itemId;

    private String loginId;

    private String type;

    private BigDecimal totalScore;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public BigDecimal getInterpersonalFraction() {
        return interpersonalFraction;
    }

    public void setInterpersonalFraction(BigDecimal interpersonalFraction) {
        this.interpersonalFraction = interpersonalFraction;
    }

    public BigDecimal getAbilityFraction() {
        return abilityFraction;
    }

    public void setAbilityFraction(BigDecimal abilityFraction) {
        this.abilityFraction = abilityFraction;
    }

    public BigDecimal getSincerityFraction() {
        return sincerityFraction;
    }

    public void setSincerityFraction(BigDecimal sincerityFraction) {
        this.sincerityFraction = sincerityFraction;
    }

    public BigDecimal getDeedFraction() {
        return deedFraction;
    }

    public void setDeedFraction(BigDecimal deedFraction) {
        this.deedFraction = deedFraction;
    }

    public BigDecimal getExperienceFraction() {
        return experienceFraction;
    }

    public void setExperienceFraction(BigDecimal experienceFraction) {
        this.experienceFraction = experienceFraction;
    }

    public String getRaterLoginId() {
        return raterLoginId;
    }

    public void setRaterLoginId(String raterLoginId) {
        this.raterLoginId = raterLoginId == null ? null : raterLoginId.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getItemId() {
        return itemId;
    }

    public void setItemId(String itemId) {
        this.itemId = itemId == null ? null : itemId.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public BigDecimal getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(BigDecimal totalScore) {
        this.totalScore = totalScore;
    }
}
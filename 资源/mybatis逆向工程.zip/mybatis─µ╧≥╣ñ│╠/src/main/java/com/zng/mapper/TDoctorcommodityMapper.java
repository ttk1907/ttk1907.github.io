package com.zng.mapper;

import com.zng.model.TDoctorcommodity;

public interface TDoctorcommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDoctorcommodity record);

    int insertSelective(TDoctorcommodity record);

    TDoctorcommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDoctorcommodity record);

    int updateByPrimaryKey(TDoctorcommodity record);
}
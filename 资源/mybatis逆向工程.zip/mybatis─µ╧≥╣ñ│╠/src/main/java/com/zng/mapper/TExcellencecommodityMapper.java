package com.zng.mapper;

import com.zng.model.TExcellencecommodity;

public interface TExcellencecommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TExcellencecommodity record);

    int insertSelective(TExcellencecommodity record);

    TExcellencecommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TExcellencecommodity record);

    int updateByPrimaryKey(TExcellencecommodity record);
}
package com.zng.mapper;

import com.zng.model.TTogether;

public interface TTogetherMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogether record);

    int insertSelective(TTogether record);

    TTogether selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogether record);

    int updateByPrimaryKey(TTogether record);
}
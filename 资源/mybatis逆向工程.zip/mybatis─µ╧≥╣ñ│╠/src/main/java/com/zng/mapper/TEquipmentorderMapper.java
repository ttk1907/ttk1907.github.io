package com.zng.mapper;

import com.zng.model.TEquipmentorder;

public interface TEquipmentorderMapper {
    int deleteByPrimaryKey(String id);

    int insert(TEquipmentorder record);

    int insertSelective(TEquipmentorder record);

    TEquipmentorder selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TEquipmentorder record);

    int updateByPrimaryKey(TEquipmentorder record);
}
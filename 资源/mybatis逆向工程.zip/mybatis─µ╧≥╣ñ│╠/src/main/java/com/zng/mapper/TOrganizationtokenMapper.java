package com.zng.mapper;

import com.zng.model.TOrganizationtoken;

public interface TOrganizationtokenMapper {
    int deleteByPrimaryKey(String id);

    int insert(TOrganizationtoken record);

    int insertSelective(TOrganizationtoken record);

    TOrganizationtoken selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TOrganizationtoken record);

    int updateByPrimaryKey(TOrganizationtoken record);
}
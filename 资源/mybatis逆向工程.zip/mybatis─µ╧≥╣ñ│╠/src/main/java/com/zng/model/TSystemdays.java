package com.zng.model;

import java.io.Serializable;

public class TSystemdays implements Serializable {
    private String id;

    private Integer zngCalculatedays;

    private Integer sysRuningdays;

    private String state;

    private String createTime;

    private String updateTime;

    private Integer priod;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public Integer getZngCalculatedays() {
        return zngCalculatedays;
    }

    public void setZngCalculatedays(Integer zngCalculatedays) {
        this.zngCalculatedays = zngCalculatedays;
    }

    public Integer getSysRuningdays() {
        return sysRuningdays;
    }

    public void setSysRuningdays(Integer sysRuningdays) {
        this.sysRuningdays = sysRuningdays;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public Integer getPriod() {
        return priod;
    }

    public void setPriod(Integer priod) {
        this.priod = priod;
    }
}
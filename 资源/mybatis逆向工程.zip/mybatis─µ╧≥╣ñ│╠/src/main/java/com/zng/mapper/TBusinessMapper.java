package com.zng.mapper;

import com.zng.model.TBusiness;

public interface TBusinessMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBusiness record);

    int insertSelective(TBusiness record);

    TBusiness selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBusiness record);

    int updateByPrimaryKey(TBusiness record);
}
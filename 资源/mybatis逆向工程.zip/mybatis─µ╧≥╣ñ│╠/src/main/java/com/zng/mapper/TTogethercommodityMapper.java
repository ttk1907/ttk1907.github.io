package com.zng.mapper;

import com.zng.model.TTogethercommodity;

public interface TTogethercommodityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogethercommodity record);

    int insertSelective(TTogethercommodity record);

    TTogethercommodity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogethercommodity record);

    int updateByPrimaryKey(TTogethercommodity record);
}
package com.zng.mapper;

import com.zng.model.TProfit;

public interface TProfitMapper {
    int deleteByPrimaryKey(String id);

    int insert(TProfit record);

    int insertSelective(TProfit record);

    TProfit selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TProfit record);

    int updateByPrimaryKey(TProfit record);
}
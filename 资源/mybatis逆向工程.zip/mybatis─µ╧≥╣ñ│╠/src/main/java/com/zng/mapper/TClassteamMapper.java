package com.zng.mapper;

import com.zng.model.TClassteam;

public interface TClassteamMapper {
    int deleteByPrimaryKey(String id);

    int insert(TClassteam record);

    int insertSelective(TClassteam record);

    TClassteam selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TClassteam record);

    int updateByPrimaryKey(TClassteam record);
}
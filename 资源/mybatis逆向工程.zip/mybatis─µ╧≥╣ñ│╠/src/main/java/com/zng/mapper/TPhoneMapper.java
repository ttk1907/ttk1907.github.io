package com.zng.mapper;

import com.zng.model.TPhone;

public interface TPhoneMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TPhone record);

    int insertSelective(TPhone record);

    TPhone selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TPhone record);

    int updateByPrimaryKey(TPhone record);
}
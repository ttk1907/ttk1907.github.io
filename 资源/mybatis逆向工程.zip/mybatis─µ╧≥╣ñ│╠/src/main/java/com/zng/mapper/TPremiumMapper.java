package com.zng.mapper;

import com.zng.model.TPremium;

public interface TPremiumMapper {
    int deleteByPrimaryKey(String id);

    int insert(TPremium record);

    int insertSelective(TPremium record);

    TPremium selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TPremium record);

    int updateByPrimaryKey(TPremium record);
}
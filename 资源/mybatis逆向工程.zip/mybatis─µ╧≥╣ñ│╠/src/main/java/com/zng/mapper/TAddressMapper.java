package com.zng.mapper;

import com.zng.model.TAddress;

public interface TAddressMapper {
    int deleteByPrimaryKey(String id);

    int insert(TAddress record);

    int insertSelective(TAddress record);

    TAddress selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TAddress record);

    int updateByPrimaryKey(TAddress record);
}
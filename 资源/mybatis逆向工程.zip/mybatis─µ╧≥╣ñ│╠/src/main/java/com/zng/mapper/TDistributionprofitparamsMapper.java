package com.zng.mapper;

import com.zng.model.TDistributionprofitparams;

public interface TDistributionprofitparamsMapper {
    int deleteByPrimaryKey(String id);

    int insert(TDistributionprofitparams record);

    int insertSelective(TDistributionprofitparams record);

    TDistributionprofitparams selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TDistributionprofitparams record);

    int updateByPrimaryKey(TDistributionprofitparams record);
}
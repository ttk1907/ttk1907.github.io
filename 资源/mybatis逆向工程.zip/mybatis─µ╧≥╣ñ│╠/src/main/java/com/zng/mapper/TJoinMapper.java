package com.zng.mapper;

import com.zng.model.TJoin;

public interface TJoinMapper {
    int deleteByPrimaryKey(String id);

    int insert(TJoin record);

    int insertSelective(TJoin record);

    TJoin selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TJoin record);

    int updateByPrimaryKey(TJoin record);
}
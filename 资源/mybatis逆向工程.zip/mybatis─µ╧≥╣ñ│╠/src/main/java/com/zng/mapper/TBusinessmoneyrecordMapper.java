package com.zng.mapper;

import com.zng.model.TBusinessmoneyrecord;

public interface TBusinessmoneyrecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBusinessmoneyrecord record);

    int insertSelective(TBusinessmoneyrecord record);

    TBusinessmoneyrecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBusinessmoneyrecord record);

    int updateByPrimaryKey(TBusinessmoneyrecord record);
}
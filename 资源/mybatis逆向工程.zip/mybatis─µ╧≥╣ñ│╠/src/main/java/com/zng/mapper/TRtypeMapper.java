package com.zng.mapper;

import com.zng.model.TRtype;

public interface TRtypeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TRtype record);

    int insertSelective(TRtype record);

    TRtype selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TRtype record);

    int updateByPrimaryKey(TRtype record);
}
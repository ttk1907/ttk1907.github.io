package com.zng.mapper;

import com.zng.model.TGrow;

public interface TGrowMapper {
    int deleteByPrimaryKey(String id);

    int insert(TGrow record);

    int insertSelective(TGrow record);

    TGrow selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TGrow record);

    int updateByPrimaryKey(TGrow record);
}
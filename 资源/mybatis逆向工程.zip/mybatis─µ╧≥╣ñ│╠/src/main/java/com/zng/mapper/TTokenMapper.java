package com.zng.mapper;

import com.zng.model.TToken;

public interface TTokenMapper {
    int deleteByPrimaryKey(String id);

    int insert(TToken record);

    int insertSelective(TToken record);

    TToken selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TToken record);

    int updateByPrimaryKey(TToken record);
}
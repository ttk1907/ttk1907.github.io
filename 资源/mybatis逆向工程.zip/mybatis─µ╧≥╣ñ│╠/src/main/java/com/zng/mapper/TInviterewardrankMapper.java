package com.zng.mapper;

import com.zng.model.TInviterewardrank;

public interface TInviterewardrankMapper {
    int deleteByPrimaryKey(String id);

    int insert(TInviterewardrank record);

    int insertSelective(TInviterewardrank record);

    TInviterewardrank selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TInviterewardrank record);

    int updateByPrimaryKey(TInviterewardrank record);
}
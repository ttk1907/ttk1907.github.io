package com.zng.mapper;

import com.zng.model.TCommunityshop;

public interface TCommunityshopMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommunityshop record);

    int insertSelective(TCommunityshop record);

    TCommunityshop selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommunityshop record);

    int updateByPrimaryKey(TCommunityshop record);
}
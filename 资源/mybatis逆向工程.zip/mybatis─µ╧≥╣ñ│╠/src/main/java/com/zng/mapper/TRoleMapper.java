package com.zng.mapper;

import com.zng.model.TRole;

public interface TRoleMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRole record);

    int insertSelective(TRole record);

    TRole selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRole record);

    int updateByPrimaryKey(TRole record);
}
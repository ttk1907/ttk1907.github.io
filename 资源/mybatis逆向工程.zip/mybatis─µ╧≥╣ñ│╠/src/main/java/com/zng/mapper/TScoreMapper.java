package com.zng.mapper;

import com.zng.model.TScore;

public interface TScoreMapper {
    int deleteByPrimaryKey(String id);

    int insert(TScore record);

    int insertSelective(TScore record);

    TScore selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TScore record);

    int updateByPrimaryKey(TScore record);
}
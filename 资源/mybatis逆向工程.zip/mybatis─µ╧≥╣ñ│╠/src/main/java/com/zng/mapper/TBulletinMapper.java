package com.zng.mapper;

import com.zng.model.TBulletin;

public interface TBulletinMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBulletin record);

    int insertSelective(TBulletin record);

    TBulletin selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBulletin record);

    int updateByPrimaryKey(TBulletin record);
}
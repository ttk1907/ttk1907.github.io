package com.zng.mapper;

import com.zng.model.TItem;

public interface TItemMapper {
    int deleteByPrimaryKey(String id);

    int insert(TItem record);

    int insertSelective(TItem record);

    TItem selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TItem record);

    int updateByPrimaryKey(TItem record);
}
package com.zng.mapper;

import com.zng.model.TPresenttogether;

public interface TPresenttogetherMapper {
    int deleteByPrimaryKey(String id);

    int insert(TPresenttogether record);

    int insertSelective(TPresenttogether record);

    TPresenttogether selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TPresenttogether record);

    int updateByPrimaryKey(TPresenttogether record);
}
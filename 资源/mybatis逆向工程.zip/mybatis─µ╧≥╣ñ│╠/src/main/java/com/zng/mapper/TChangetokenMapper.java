package com.zng.mapper;

import com.zng.model.TChangetoken;

public interface TChangetokenMapper {
    int deleteByPrimaryKey(String id);

    int insert(TChangetoken record);

    int insertSelective(TChangetoken record);

    TChangetoken selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TChangetoken record);

    int updateByPrimaryKey(TChangetoken record);
}
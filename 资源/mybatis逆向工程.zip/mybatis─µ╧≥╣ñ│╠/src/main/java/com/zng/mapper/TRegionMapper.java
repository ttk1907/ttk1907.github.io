package com.zng.mapper;

import com.zng.model.TRegion;

public interface TRegionMapper {
    int deleteByPrimaryKey(String id);

    int insert(TRegion record);

    int insertSelective(TRegion record);

    TRegion selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TRegion record);

    int updateByPrimaryKey(TRegion record);
}
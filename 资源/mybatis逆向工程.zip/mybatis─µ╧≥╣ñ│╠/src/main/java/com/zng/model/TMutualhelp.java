package com.zng.model;

import java.io.Serializable;

public class TMutualhelp implements Serializable {
    private String id;

    private String createTime;

    private String loginId;

    private String state;

    private String updateTime;

    private String type;

    private String dayUrl;

    private String monthUrl;

    private String healthRecord;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getDayUrl() {
        return dayUrl;
    }

    public void setDayUrl(String dayUrl) {
        this.dayUrl = dayUrl == null ? null : dayUrl.trim();
    }

    public String getMonthUrl() {
        return monthUrl;
    }

    public void setMonthUrl(String monthUrl) {
        this.monthUrl = monthUrl == null ? null : monthUrl.trim();
    }

    public String getHealthRecord() {
        return healthRecord;
    }

    public void setHealthRecord(String healthRecord) {
        this.healthRecord = healthRecord == null ? null : healthRecord.trim();
    }
}
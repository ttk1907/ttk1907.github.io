package com.zng.mapper;

import com.zng.model.TBanner;

public interface TBannerMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBanner record);

    int insertSelective(TBanner record);

    TBanner selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBanner record);

    int updateByPrimaryKey(TBanner record);
}
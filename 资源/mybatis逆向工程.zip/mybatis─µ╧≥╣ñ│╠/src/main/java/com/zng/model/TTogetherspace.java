package com.zng.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TTogetherspace implements Serializable {
    private String id;

    private String loginId;

    private String createTime;

    private String updateTime;

    private String state;

    private String contractState;

    private String signState;

    private String financialState;

    private String reviewState;

    private String lockState;

    private String startTime;

    private String endTime;

    private String cityName;

    private String cityId;

    private BigDecimal tokenPrice;

    private BigDecimal lockToken;

    private String yearNum;

    private String name;

    private String togetherSpaceAddress;

    private String parentPhone;

    private String parentLoginId;

    private BigDecimal agencyFees;

    private BigDecimal targetPerformance;

    private BigDecimal currentPerformance;

    private BigDecimal onePerformance;

    private BigDecimal twoPerformance;

    private BigDecimal threePerformance;

    private BigDecimal fourPerformance;

    private String customerId;

    private String transactionNo;

    private String batchId;

    private String contractIdOne;

    private String signLoginId;

    private String contractIdThree;

    private String contractIdTwo;

    private String applyId;

    private String areaState;

    private String transferImg;

    private String receivePaymentImg;

    private String isTransfer;

    private static final long serialVersionUID = 1L;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(String loginId) {
        this.loginId = loginId == null ? null : loginId.trim();
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime == null ? null : createTime.trim();
    }

    public String getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(String updateTime) {
        this.updateTime = updateTime == null ? null : updateTime.trim();
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    public String getContractState() {
        return contractState;
    }

    public void setContractState(String contractState) {
        this.contractState = contractState == null ? null : contractState.trim();
    }

    public String getSignState() {
        return signState;
    }

    public void setSignState(String signState) {
        this.signState = signState == null ? null : signState.trim();
    }

    public String getFinancialState() {
        return financialState;
    }

    public void setFinancialState(String financialState) {
        this.financialState = financialState == null ? null : financialState.trim();
    }

    public String getReviewState() {
        return reviewState;
    }

    public void setReviewState(String reviewState) {
        this.reviewState = reviewState == null ? null : reviewState.trim();
    }

    public String getLockState() {
        return lockState;
    }

    public void setLockState(String lockState) {
        this.lockState = lockState == null ? null : lockState.trim();
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime == null ? null : startTime.trim();
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime == null ? null : endTime.trim();
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName == null ? null : cityName.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public BigDecimal getTokenPrice() {
        return tokenPrice;
    }

    public void setTokenPrice(BigDecimal tokenPrice) {
        this.tokenPrice = tokenPrice;
    }

    public BigDecimal getLockToken() {
        return lockToken;
    }

    public void setLockToken(BigDecimal lockToken) {
        this.lockToken = lockToken;
    }

    public String getYearNum() {
        return yearNum;
    }

    public void setYearNum(String yearNum) {
        this.yearNum = yearNum == null ? null : yearNum.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getTogetherSpaceAddress() {
        return togetherSpaceAddress;
    }

    public void setTogetherSpaceAddress(String togetherSpaceAddress) {
        this.togetherSpaceAddress = togetherSpaceAddress == null ? null : togetherSpaceAddress.trim();
    }

    public String getParentPhone() {
        return parentPhone;
    }

    public void setParentPhone(String parentPhone) {
        this.parentPhone = parentPhone == null ? null : parentPhone.trim();
    }

    public String getParentLoginId() {
        return parentLoginId;
    }

    public void setParentLoginId(String parentLoginId) {
        this.parentLoginId = parentLoginId == null ? null : parentLoginId.trim();
    }

    public BigDecimal getAgencyFees() {
        return agencyFees;
    }

    public void setAgencyFees(BigDecimal agencyFees) {
        this.agencyFees = agencyFees;
    }

    public BigDecimal getTargetPerformance() {
        return targetPerformance;
    }

    public void setTargetPerformance(BigDecimal targetPerformance) {
        this.targetPerformance = targetPerformance;
    }

    public BigDecimal getCurrentPerformance() {
        return currentPerformance;
    }

    public void setCurrentPerformance(BigDecimal currentPerformance) {
        this.currentPerformance = currentPerformance;
    }

    public BigDecimal getOnePerformance() {
        return onePerformance;
    }

    public void setOnePerformance(BigDecimal onePerformance) {
        this.onePerformance = onePerformance;
    }

    public BigDecimal getTwoPerformance() {
        return twoPerformance;
    }

    public void setTwoPerformance(BigDecimal twoPerformance) {
        this.twoPerformance = twoPerformance;
    }

    public BigDecimal getThreePerformance() {
        return threePerformance;
    }

    public void setThreePerformance(BigDecimal threePerformance) {
        this.threePerformance = threePerformance;
    }

    public BigDecimal getFourPerformance() {
        return fourPerformance;
    }

    public void setFourPerformance(BigDecimal fourPerformance) {
        this.fourPerformance = fourPerformance;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId == null ? null : customerId.trim();
    }

    public String getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(String transactionNo) {
        this.transactionNo = transactionNo == null ? null : transactionNo.trim();
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId == null ? null : batchId.trim();
    }

    public String getContractIdOne() {
        return contractIdOne;
    }

    public void setContractIdOne(String contractIdOne) {
        this.contractIdOne = contractIdOne == null ? null : contractIdOne.trim();
    }

    public String getSignLoginId() {
        return signLoginId;
    }

    public void setSignLoginId(String signLoginId) {
        this.signLoginId = signLoginId == null ? null : signLoginId.trim();
    }

    public String getContractIdThree() {
        return contractIdThree;
    }

    public void setContractIdThree(String contractIdThree) {
        this.contractIdThree = contractIdThree == null ? null : contractIdThree.trim();
    }

    public String getContractIdTwo() {
        return contractIdTwo;
    }

    public void setContractIdTwo(String contractIdTwo) {
        this.contractIdTwo = contractIdTwo == null ? null : contractIdTwo.trim();
    }

    public String getApplyId() {
        return applyId;
    }

    public void setApplyId(String applyId) {
        this.applyId = applyId == null ? null : applyId.trim();
    }

    public String getAreaState() {
        return areaState;
    }

    public void setAreaState(String areaState) {
        this.areaState = areaState == null ? null : areaState.trim();
    }

    public String getTransferImg() {
        return transferImg;
    }

    public void setTransferImg(String transferImg) {
        this.transferImg = transferImg == null ? null : transferImg.trim();
    }

    public String getReceivePaymentImg() {
        return receivePaymentImg;
    }

    public void setReceivePaymentImg(String receivePaymentImg) {
        this.receivePaymentImg = receivePaymentImg == null ? null : receivePaymentImg.trim();
    }

    public String getIsTransfer() {
        return isTransfer;
    }

    public void setIsTransfer(String isTransfer) {
        this.isTransfer = isTransfer == null ? null : isTransfer.trim();
    }
}
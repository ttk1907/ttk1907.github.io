package com.zng.mapper;

import com.zng.model.TTogetherspace;

public interface TTogetherspaceMapper {
    int deleteByPrimaryKey(String id);

    int insert(TTogetherspace record);

    int insertSelective(TTogetherspace record);

    TTogetherspace selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TTogetherspace record);

    int updateByPrimaryKey(TTogetherspace record);
}
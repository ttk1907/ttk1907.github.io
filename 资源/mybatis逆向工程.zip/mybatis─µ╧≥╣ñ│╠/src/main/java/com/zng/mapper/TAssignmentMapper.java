package com.zng.mapper;

import com.zng.model.TAssignment;

public interface TAssignmentMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TAssignment record);

    int insertSelective(TAssignment record);

    TAssignment selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TAssignment record);

    int updateByPrimaryKey(TAssignment record);
}
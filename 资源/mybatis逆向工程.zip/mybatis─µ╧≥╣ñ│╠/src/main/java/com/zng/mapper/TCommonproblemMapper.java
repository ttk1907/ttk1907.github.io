package com.zng.mapper;

import com.zng.model.TCommonproblem;

public interface TCommonproblemMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommonproblem record);

    int insertSelective(TCommonproblem record);

    TCommonproblem selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommonproblem record);

    int updateByPrimaryKey(TCommonproblem record);
}
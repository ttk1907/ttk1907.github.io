package com.zng.mapper;

import com.zng.model.TBigheromission;

public interface TBigheromissionMapper {
    int deleteByPrimaryKey(String id);

    int insert(TBigheromission record);

    int insertSelective(TBigheromission record);

    TBigheromission selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TBigheromission record);

    int updateByPrimaryKey(TBigheromission record);
}
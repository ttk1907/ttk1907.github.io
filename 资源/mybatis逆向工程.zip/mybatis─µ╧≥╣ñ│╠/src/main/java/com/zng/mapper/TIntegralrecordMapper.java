package com.zng.mapper;

import com.zng.model.TIntegralrecord;

public interface TIntegralrecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(TIntegralrecord record);

    int insertSelective(TIntegralrecord record);

    TIntegralrecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TIntegralrecord record);

    int updateByPrimaryKey(TIntegralrecord record);
}
package com.zng.mapper;

import com.zng.model.TCommunityshopactivity;

public interface TCommunityshopactivityMapper {
    int deleteByPrimaryKey(String id);

    int insert(TCommunityshopactivity record);

    int insertSelective(TCommunityshopactivity record);

    TCommunityshopactivity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TCommunityshopactivity record);

    int updateByPrimaryKey(TCommunityshopactivity record);
}
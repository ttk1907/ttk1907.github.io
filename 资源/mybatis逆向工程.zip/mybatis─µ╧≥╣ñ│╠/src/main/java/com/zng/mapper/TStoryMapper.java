package com.zng.mapper;

import com.zng.model.TStory;

public interface TStoryMapper {
    int deleteByPrimaryKey(String id);

    int insert(TStory record);

    int insertSelective(TStory record);

    TStory selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TStory record);

    int updateByPrimaryKey(TStory record);
}
package com.zng.mapper;

import com.zng.model.TStatistics;

public interface TStatisticsMapper {
    int deleteByPrimaryKey(String id);

    int insert(TStatistics record);

    int insertSelective(TStatistics record);

    TStatistics selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TStatistics record);

    int updateByPrimaryKey(TStatistics record);
}
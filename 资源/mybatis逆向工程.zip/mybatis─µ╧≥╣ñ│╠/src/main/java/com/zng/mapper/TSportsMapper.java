package com.zng.mapper;

import com.zng.model.TSports;

public interface TSportsMapper {
    int deleteByPrimaryKey(String id);

    int insert(TSports record);

    int insertSelective(TSports record);

    TSports selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TSports record);

    int updateByPrimaryKey(TSports record);
}
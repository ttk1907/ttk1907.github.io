package com.ttk.springcloud.dao;

import com.ttk.springcloud.entities.Payment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author ttk
 * @created 2020-09-15 22:00
 * @function ""
 */
@Mapper
public interface PaymentDao {

    public int create(Payment payment);

    public Payment getPaymentById(@Param("id") int id);
}

package com.ttk.springcloud.service.impl;

import com.ttk.springcloud.dao.PaymentDao;
import com.ttk.springcloud.entities.Payment;
import com.ttk.springcloud.service.PaymentService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author ttk
 * @created 2020-09-15 22:17
 */
@Service
public class PaymentServiceImpl implements PaymentService {
    @Resource
    private PaymentDao paymentDao;


    @Override
    public int create(Payment payment) {
        return paymentDao.create(payment);
    }

    @Override
    public Payment getPaymentById(int id) {
        return paymentDao.getPaymentById(id);
    }

}

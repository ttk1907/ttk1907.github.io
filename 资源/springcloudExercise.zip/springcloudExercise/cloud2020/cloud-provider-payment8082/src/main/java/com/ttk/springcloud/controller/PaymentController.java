package com.ttk.springcloud.controller;

import com.ttk.springcloud.entities.CommonResult;
import com.ttk.springcloud.entities.Payment;
import com.ttk.springcloud.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author ttk
 * @created 2020-09-15 22:21
 */
@RestController
@Slf4j
@RequestMapping("payment")
public class PaymentController {

    @Resource
    private PaymentService paymentService;
    @Value("${server.port}")
    private String serverPort;

    @PostMapping
    public CommonResult create(@RequestBody Payment payment){
        int result = paymentService.create(payment);
        log.info("*****插入结果:"+result);
        if (result>0){
            return new CommonResult(200,"插入数据成功,端口号为:"+serverPort,result);
        }else{
            return new CommonResult(404,"插入数据失败",null);
        }
    }

    @GetMapping
    public CommonResult<Payment> getPaymentById(@RequestParam(name = "id") int id){
        Payment result = paymentService.getPaymentById(id);
        log.info("*****插入结果:"+result);
        if (result!=null){
            return new CommonResult(200,"查询成功,端口号为:"+serverPort,result);
        }else{
            return new CommonResult(404,"查询失败，id为："+id,null);
        }
    }


}

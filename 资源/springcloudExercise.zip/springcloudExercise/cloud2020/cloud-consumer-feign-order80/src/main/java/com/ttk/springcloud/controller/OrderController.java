package com.ttk.springcloud.controller;

import com.ttk.springcloud.entities.CommonResult;
import com.ttk.springcloud.entities.Payment;
import com.ttk.springcloud.service.PaymentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author ttk
 * @created 2020-09-16 22:23
 */
@RestController
@Slf4j
@RequestMapping("/consumer/payment")
public class OrderController {

    @Resource
    private PaymentService paymentService;

    @PostMapping
    public CommonResult create(Payment payment){
        return paymentService.create(payment);
    }

    @GetMapping
    public CommonResult<Payment> getPaymentById(int id){
        return paymentService.getPaymentById(id);
    }
}

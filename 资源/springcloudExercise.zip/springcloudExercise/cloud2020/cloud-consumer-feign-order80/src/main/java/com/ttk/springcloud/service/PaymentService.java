package com.ttk.springcloud.service;

import com.ttk.springcloud.entities.CommonResult;
import com.ttk.springcloud.entities.Payment;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author ttk
 * @created 2020-09-25 22:04
 * @function ""
 */
@FeignClient(value="CLOUD-PAYMENT-SERVICE")
@Component
public interface PaymentService {

    @PostMapping("payment")
    CommonResult create(@RequestBody Payment payment);

    @GetMapping("payment")
    CommonResult<Payment> getPaymentById(@RequestParam(name = "id") int id);
}

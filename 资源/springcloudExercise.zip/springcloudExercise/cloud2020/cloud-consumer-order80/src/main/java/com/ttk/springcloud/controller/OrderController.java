package com.ttk.springcloud.controller;

import com.ttk.springcloud.entities.CommonResult;
import com.ttk.springcloud.entities.Payment;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;

/**
 * @author ttk
 * @created 2020-09-16 22:23
 */
@RestController
@Slf4j
@RequestMapping("/consumer/payment")
public class OrderController {

    public static final String paymentUrl = "http://CLOUD-PAYMENT-SERVICE";

    @Resource
    private RestTemplate restTemplate;

    @PostMapping
    public CommonResult<Payment> create(Payment payment){
        return restTemplate.postForObject(paymentUrl+"/payment",payment,CommonResult.class);
    }

    @GetMapping
    public CommonResult<Payment> getPaymentById(String id){
        return restTemplate.getForObject(paymentUrl+"/payment?id="+id,CommonResult.class);
    }
}
